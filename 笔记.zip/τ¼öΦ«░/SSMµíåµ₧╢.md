# nhoSSM框架

一、SpringMVC

二、Spring

三、MyBatis

## 一、spring



### 1、spring基础

1、客户关系管理系统 CRM

	> CRM是一个不断加强与顾客交流，不断了解顾客需求顾客需求，并不断对产品及服务进		行改进和提高以满足顾客的需求的连续的过程

2、IOC控制反转 

	>将对象创建交给Spring工厂进行

3、AOP 面向切面编程 

> 基于动态代理的功能增强方式

4、spring的好处![屏幕快照 2019-08-11 上午10.54.13](/Users/tony/笔记/image/屏幕快照 2019-08-11 上午10.54.13.png)



### 2、Log4j

> 用于输出Log日志文件

1、Log4j配置文件	![屏幕快照 2019-08-11 下午4.28.19](/Users/tony/Desktop/屏幕快照 2019-08-11 下午4.28.19.png)

代码

```中文
###用控制输出配置##
log4j.appender.console = org.apache.log4j.ConsoleAppender
###指定输出到控制台##
log4j.appender.console.Target = System.out
log4j.appender.console.Threshold = DEBUG ;
log4j.appender.console.layout = org.apache.log4j.PatternLayout
## 输出格式配置##
log4j.appender.console.layout.ConversionPattern =  %d{ABSOLUTE} %5p %c{1}:%L - %m%n

### 配置输出到文件 ###
log4j.appender.fileAppender = org.apache.log4j.FileAppender
### 设置输出文件到路径 ###
log4j.appender.fileAppender.File = /Users/tony/logs/log1.log
## 输出文件到设置，如果为true则输出到日志文件继续向下追加，如果为false则覆盖原油到日志文件##
log4j.appender.fileAppender.Append = false
## 设置最低级到优先级##
log4j.appender.fileAppender.Threshold = DEBUG
log4j.appender.fileAppender.layout = org.apache.log4j.PatternLayout
## 输出格式配置##
log4j.appender.fileAppender.layout.ConversionPattern = %-d{yyyy-MM-dd HH:mm:ss} [%t:%r]-[%p] %m%n

##配置根##
##选择调用到优先级，以及输出##
log4j.rootLogger = all,fileAppender,console

## 日志优先级 ##
## OFF、FATAL、ERROR、WARN、INFO、DEBUG、ALL ##
```

2、打印日志文件

![屏幕快照 2019-08-11 下午4.41.01](/Users/tony/笔记/image/屏幕快照 2019-08-11 下午4.41.01.png)代码

```
package com.Tony.log4j;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.Test;


public class Log4JText {

    private Logger logger = Logger.getLogger(Log4JText.class);

    @Test
    public void printLog(){
        logger.info("这是info的日志输出");
        logger.error("这是error的日志输出");
        logger.debug("这是debug的日志输出");
        logger.warn("这是warn的日志输出");

        logger.error("创建一个异常",new Exception("异常的内容"));
    }
}

```

1. 需要得到Logger的实例化对象，在Logger中有静态的实例方法需要传入类名称.class
2. 在需要输出的地方输出日志，日志内容
3. 可以创建一个异常并抛出



### 3、Spring的IOC控制反转以及依赖注入

​		采用传统方式开发会出现new出对象的情况，造成耦合依赖太高，所以可以通过Spring的IOC来解决，通过IOC去帮助你创建对象并注入到你所设置的属性中

​	1、配置文件applicationContext（存放在Resources资源文件中保存）

​		创建applicationContext方法![屏幕快照 2019-08-12 上午11.23.57](/Users/tony/笔记/image/屏幕快照 2019-08-12 上午11.23.57.png)

代码

```

<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">
    <!--
        id属性：为创建对象时到标示，在代码中调用对象时候用到
        class属性：具体创建到对象，需要写入全类名（包+类名称）
    -->
    <bean id="userDAO" class="Tony.igeek.UserDAOImpl"></bean>
    <bean id="userService" class="Tony.igeek.UserServiceImple">
        <!--
            依赖注入
            name属性：userService对象中的userDAO属性
                - 会自动将生成好的userDAO对象通过set方法注入到userService对象中userDAO属性
            ref属性：需要创建的对象
                - 会通过spring容器中查找userDAO对象，并注入到userService中到UserDAO属性
        -->
        <property name="userDAO" ref="userDAO" ></property>
    </bean>
</beans>
```

2、在代码中调用

![屏幕快照 2019-08-12 上午11.28.13](/Users/tony/笔记/image/屏幕快照 2019-08-12 上午11.28.13.png)

代码

```
public class UserTest {
    @Test
    public void start(){
        ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
        IUserService userService = (IUserService) ac.getBean("userService");
        userService.login();
    }
}
```

​	1、通过实例化AplicationContext接口的实现类ClassPathXmlApplicationContext对象，在构造方法中传入配置好的Xml文件名

​	2、通过ApplicationContext对象的getBean()方法返回创建好的对象，需要传入配置文件的id参数，如果在Bean标签中有porperty标签则会自动将ref属性的对象注入到name属性中	

PS：在创建对象的时候可以通过Bean创建，也可以通过对象.class创建

```
IUserService userService = (IUserService) ac.getBean(IUserService.class);
```

 但是这样创建的时候，在配置文件中如果出现两个class相同但是Name/id不相同的Bean就会出异常

```
<bean id="userDAO" class="Tony.igeek.UserDAOImpl"></bean>
<bean id="userService" class="Tony.igeek.UserServiceImple">
    <!--
        依赖注入
        name属性：userService对象中的userDAO属性
            - 会自动将生成好的userDAO对象通过set方法注入到userService对象中userDAO属性
        ref属性：需要创建的对象
            - 会通过spring容器中查找userDAO对象，并注入到userService中到UserDAO属性
    -->
    <property name="userDAO" ref="userDAO" ></property>
</bean>
<bean id="userService2" class="Tony.igeek.UserServiceImple">
    <!--
        依赖注入
        name属性：userService对象中的userDAO属性
            - 会自动将生成好的userDAO对象通过set方法注入到userService对象中userDAO属性
        ref属性：需要创建的对象
            - 会通过spring容器中查找userDAO对象，并注入到userService中到UserDAO属性
    -->
    <property name="userDAO" ref="userDAO" ></property>
</bean>
```

所以在正常情况下都是用iD的方式来创建对象



### 4、实例化Bean的四种方法

#### 1.通过Bean标签中的ID属性与class属性进行配置实例化

配置文件

```
<!--
    通过ID进行Bean的实例化
-->
<bean id="bean1" class="Tony.igeek2.Bean1" />
```

类的定义

```
public class Bean1 {
    private String name ;

}
```

实例化Bean

```
public void Bean1(){
    ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
    Bean1 bean1 = (Bean1) ac.getBean("bean1");
    System.out.println(bean1);
}
```

#### 	2.通过类中静态方法实例化对象

配置文件

```
<!--
        2、静态工厂实例化Bean
        通过类中的静态方法实例化对象
    -->
    <bean id="bean2" class="Tony.igeek2.Bean2" factory-method="getBean2" />
```

类的定义

```
public class Bean2 {
    private String data ;

    public Bean2(String data) {
        this.data = data;
    }

    private static Bean2 getBean2(){
        return new Bean2("hello");
    }
}
```

实例化Bean

```
public void bean2(){
    ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
    Bean2 bean2 = (Bean2) ac.getBean("bean2");
    System.out.println(bean2);
}
```

> 通过配置文件中的factory-method属性指定类中的静态方法，则Spring会自动调用factory-method所指定的方法完成类的创建

#### 	3.通过自定义工厂模式实例化Bean

配置文件

```
<!--
    3、通过实例化自定义工厂实例化Bean
        -得到工厂的实例化对象
        -在通过Factory-bean属性指定实例化工厂的id
        -再通过Factory-method属性指定工厂方法返回实例化对象
 -->
<bean id="bean3Factor" class="Tony.igeek2.Bean3Factor" />
<bean id="bean3" factory-bean="bean3Factor" factory-method="getBean3"/>
```

bean3Factory工厂类的定义

```
package Tony.igeek2;

public class Bean3Factor {
    public Bean3 getBean3(){
        return new Bean3();
    }
}
```

bean3类的定义

```
package Tony.igeek2;

public class Bean3 {

}
```

实例化Bean

```
public void bean3(){
    ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
    Bean3 bean3 = (Bean3) ac.getBean("bean3");
    System.out.println(bean3);
}
```

>通过配置文件中的factory-bean指定需要那个工厂实例对象，再通过factory-method指定具体的方法实现类的创建

​	4.通过实现FactoryBean接口实例化Bean

配置文件

```
<!--
    4、通过实现Factory接口返回Bean的实例化对象
   再实现FactoryBean接口时候需要复写中的getObject方法 这个方法是返回具体的实现了类
-->
<bean id="bean4" class="Tony.igeek2.Bean4" />
```

Bean4FactoryBean类定义

```
public class Bean4FactoryBean implements FactoryBean<Bean4> {
    @Override
    public Bean4 getObject() throws Exception {
        return new Bean4() ;
    }

    @Override
    public Class<?> getObjectType() {
        return null;
    }

    @Override
    public boolean isSingleton() {
        return false;
    }
}
```

Bean4的定义

```
package Tony.igeek2;

public class Bean4 {
}
```

实例化Bean

```
@Test
public void bean4(){
    ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
    Bean4 bean4 = (Bean4) ac.getBean("bean4");
    System.out.println(bean4);
}
```

>通过实现FactoryBean的接口，复写getObject、getObjectType、isSingleton三个方法，其中getObject方法可以创建对象并返回，再Spring中框架会自动判断是否腹泻类FactoryBean接口，如果复写接口则会自动调用getObject方法，如果没有复写此方法，则通过构造方式实例化

#### PS：面试题

​	FactoryBean与BeanFactory的区别

FactoryBean是一个接口，他是一个工具接口，实现此方法可以创建具体的类

BeanFactory则是一个Spring容器的基础实现类，管理着Bean的工厂，ApplicationContext则就是这个类的子类



### 5、Bean的作用域

#### ![屏幕快照 2019-08-13 上午10.33.06](/Users/tony/笔记/image/屏幕快照 2019-08-13 上午10.33.06.png)

#### 	1.singleton单例设计模式

	>单例设计模式，在Spring容器中只会存在一个实例对象
	>
	>在Spring中默认就是单例的模式，即使不写scope属性也会默认singleton

​	配置文件

```
<bean id="singleton" class="Tony.igeek3.SingletonBean" scope="singleton" />
```

#### 	2.prototype多例设计模式

>多例设计模式，在Spring容器中每获取一次对象都会创建新的对象

配置文件

```
<bean id="prototype" class="Tony.igeek3.PrototypeBean" scope="prototype" />
```

Ps

```
Bean的作用域
在Bean标签中，scope属性可以指定在容器中是否存在单个实例或者多个实例对象

-singleton ：表示单个实例化对象，即使获取无数次在容器只有一个实例
-prototype ：表示多个实例化对象，每次获取都会创建一个新的实例对象
```



### 6、Bean的生命周期

#### 	代码

```
public class LifeCycleBean {
    
    public LifeCycleBean() {
        System.out.println("构造方法被调用");
    }

    public void init() {
        System.out.println("在构造方法执行后晚调用 inst");
    }

    public void save(){
        System.out.println("在init方法后，被用户调用");
    }

    public void destroy() {
        System.out.println("在对象被销毁之前调用");
    }
}
```

配置文件

```
<!--
    Bean的生命周期
    init-method属性所指定的方法是在构造方法执行完成中后被调用
    destroy-method属性所指定的方法是在对象被销毁前调用
-->
<bean id="LifeCycleBean" class="Tony.igeek4.LifeCycleBean" init-method="init" destroy-method="destroy" />
```

#### ps：注意

```
如果用Junit的Debug模式执行，在测试完成后，Spring容器还没有来得及销毁对象，JVM就被关闭了，所以destroy的方法并不会被执行
```

手动关闭容器

```
((ClassPathXmlApplicationContext) ac).close();
```

通过向下转型成实现类，在ClasspathXmlapplicationContext类中有Close方法关闭Spring容器，之后就可以执行Destroy的方法



### 7、后处理Bean

>后处理Bean，可以在不修改源代码的情况下进行数据的初始化操作

代码

```
public class BeanPostProcess implements BeanPostProcessor {

    /**
     * 实现在构造方法之后执行
     * @param o 返回的Bean对象
     * @param s 返回的Bean名称，也是配置文件中的BeanID
     * @return 返回Bean对象
     * @throws BeansException
     */
    @Override
    public Object postProcessBeforeInitialization(Object o, String s) throws BeansException {
        if (s.equals("LifeCycleBean")){
            System.out.println("postProcessBeforeInitialization：在构造方法之后调用");
        }
        return o;
    }

    /**
     * 在Init方法后执行
     * @param o 返回的Bean对象
     * @param s 返回的bean名称，也是配置文件中的BeanID
     * @return 返回Bean对象
     * @throws BeansException
     */
    @Override
    public Object postProcessAfterInitialization(Object o, String s) throws BeansException {
        if (s.equals("LifeCycleBean")){
            System.out.println("postProcessAfterInitialization：在Init方法后执行");
        }
        return o;
    }
}
```

一个类实现了BeanprostProcessor接口，会有需要复写两个方法，分别在构造器之后调用和一个在Init方法后调用，两个方法都会接收两个参数，一个是Bean的对象和Bean在配置文件中的ID，每当创建一个Bean的时候Spring都会执行这两个方法，只要判断id是否和配置文件中相同，然后再写具体的逻辑代码，返回Bean的对象

配置文件

```
<!--
    后处理的Bean
-->
<bean class="Tony.igeek4.BeanPostProcess" />
```



### 8、通过构造方法传递参数

>可以通过配置文件进行构造方法传递的参数进行初始化

类的定义

```
public class Car {
    private int id;
    private String name;
    private double price;

    public Car(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

}
```

配置文件

```
<bean id="Car" class="Tony.iggek5.Car">
    <!--
        通过三种方式向构造方法传入参数
        index-通过属性的顺序进行参数的传入
        name-通过属性的名称传入参数
        type-通过属性的类型传入传输
    -->
    <constructor-arg index="0" value="1" />
    <constructor-arg name="name" value="梅赛德斯奔驰"></constructor-arg>
    <constructor-arg name="price" value="999d"/>
</bean>
```

可以通过三种方式进行属性的传递



### 9、通过Set方法注入属性

类的定义

```
public class Person {
    private int id ;
    private String name ;
    private Car car ;

    @Override
    public String toString() {
        return "Person{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", car=" + car +
                '}';
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCar(Car car) {
        this.car = car;
    }
}
```

配置文件

```
<!--
    通过Set方法注入参数
-->
<bean id="person" class="Tony.iggek5.Person" >
    <!--
        两种种方式进行Set方法注入参数
        -name 指定的Name的Set方法，并不是指定属性名称
        -value 具体的值
        -ref 指定复杂类型的数值，或者对象的引用
    -->
    <property name="name" value="Tom"/>
    <property name="id" value="001" />
    <property name="car" ref="Car"/>
</bean>
```

#### PS：注意

在配置文件中，property标签中name属性并不是指定属性的名称，而是匹配属性的Set方法，Spring会去找配置的name值的set方法



### 10、其他方式注入

#### 	1.是用空间名称进行参数的注入

配置文件

```
xmlns:p="http://www.springframework.org/schema/p"
<!--
    通过名称空间进行参数的注入
    p:后面加上属性名称，跟上值
-->
 <bean id="person2" class="Tony.iggek5.Person" p:id="002" p:name="Ben" p:car-ref="Car"/>
```

>在配置文件需要导入P标签

#### 	2.通过sqEL表达式进行参数的注入

配置文件

```
xmlns:p="http://www.springframework.org/schema/p"
<!--
    用sqEL表达式进行参数的注入
-->
<bean id="person3" class="Tony.iggek5.Person" p:id="#{123}" p:name="#{Car.name}" p:car="#{Car}"/>
```

>同样需要导入P标签，同时在需要应用的对象需要有get方法

#### 	3.对List集合参数的注入

配置文件

```
<property name="list">
    <list>
        <value>Tony</value>
        <value>Tucker</value>
        <value>HelloWrod</value>
    </list>
</property>
```

> value表示的需要传递的参数

#### 	4.对set集合的注入

配置文件

```
<property name="set">
    <set>
        <value>19999</value>
        <value>29999</value>
    </set>
</property>
```

>同样和List集合一样

#### 	5.对Map集合进行注入

配置文件

```
<property name="map">
    <map>
        <entry key="001" value="Tomcat1"/>
        <entry key="002" value="Tomcat2"/>
    </map>
</property>
```

#### 	6.对properties集合进行注入

配置文件

```
<property name="properties">
    <props>
        <prop key="data1">数据1</prop>
        <prop key="data2">数据2</prop>
    </props>
</property>
```

>properties集合是一个key与value集合的对象，key与value的数据类型都是String



### 11、分模式开发

#### 		1.在构造方法中传入多个配置文件

		>当遇到多个配置文件的时候，可以通过在ClasspathXmlContext的构造方法传入多个配置文件

代码

```
@Test void funPerson4(){
    ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml","applicationContext2.xml");
    CollcationBean collcationBean = (CollcationBean) ac.getBean("collcationBean");
    System.out.println(collcationBean);
}
```

传入的参数可以是一个数组

#### 		2.在配置文件中引入配置文件

>可以在配置文件中通过import标签引入其他的配置文件

代码

```
<!--
    通过引入其他的配置文件
-->
<import resource="applicationContext2.xml" />
```

#### 	PS：注意

在实际的开发中，是用最多的是第2种，通常会有一个总的配置文件去引入个个配置文件



### 12、ContextLoaderListener监听器

>​		在之前的学习中，通过new ClassPathXmlContext() 来获取applicationContext对象，从而读取XMl配置文件的Bean节点来获取对象，在这种形式中会出现一个很明显的问题，每当想要获取一个对象的时候都需要去创建一个ClassPathXmlContext的对象，每次创建都会重新读取XMl配置文件，每次读取有会创建新的对象，造成不必要的内存浪费。
>
>​		所以为了解决这样的问题，是用来ContextLoaderListener监听器，来保证每次只读取一次配置文件

​	注意：由于ContextLoaderListener是org.springframework.web.context下的类，所以需要额外的导入Spring-Web的jar包，导入的jar包要与Spring的jar版本要一致，否则会出现异常



​	配置文件 web.xml

```
<!--
  配置ContextLoaderListener监听器所需要的上下文属性
-->
<context-param>
  <!--监听器需要的属性名称-->
  <param-name>contextConfigLocation</param-name>
  <!--对应的配置文件路径-->
  <param-value>WEB-INF/resources/applicationContext.xml</param-value>
</context-param>

<!--配置监听器-->
<listener>
  <!--配置监听器所在的类-->
  <listener-class>org.springframework.web.context.ContextLoaderListener</listener-class>
</listener>
```

>在ContextLoadderListener中有一个contextConfigLocation的属性，这个属性是指向applicationContext.xml配置文件的相对路径，所有通过Context-param标签来指定配置文件的路径，监听器会自动读取这个上下文属性

​		代码

```
WebApplicationContext ac = WebApplicationContextUtils.getWebApplicationContext(this.getServletContext());
```

> 通过WebApplicationContextUtils.getWebApplicationContext()方法取的WebApplicationContext对象
>
> 获取到的WebApplicationContext对象就可以通过getBean方法获取配置方法中的Bean节点取得对象

#### 	PS:注意

​	在使用属性注入，或者对象注入的时候，要反向考虑。

​	例如Service层调用DAO层，就可以在创建Service层对象的时候把需要调用的DAO的对象注入到Service层	DAO属性，Service在通过this.对象调用相对应的方法

​	由于ContextLoaderListener是org.springframework.web.context下的类，所以需要额外的导入Spring-Web的jar包，导入的jar包要与Spring的jar版本要一致，否则会出现异常



### 13、通过@Component注解实现类的创建

>在之前都是通过在applicationContext.xml文件进行配置Bean节点来获取对象
>
>也可以通过在对象注解@component来实例化对象

applicationContext配置文件

```
<!--
    需要导入xsd才能够使用此标签
     xmlns:context="http://www.springframework.org/schema/context"
    xsi:schemaLocation="http://www.springframework.org/schema/context
   http://www.springframework.org/schema/context/spring-context.xsd"

   base-package 此属性表示需要扫描的包，如果在这个包下面的类有Component的注解那么会自动交给IOC容器实例化对象
-->
<context:component-scan base-package="Tony" ></context:component-scan>
```

注意：需要导入spring-context.xsd的文件才可以有context:component-scan标签

类的定义

```
/*
  <Bean name="CustomerService class="Tony.iggek6.CustomerService" />
  与在配置文件中配置完全相同
* */
@Component(value = "CustomerService")
public class CustomerService {
    public void sean() {
        System.out.println("调用来CustomerService层");
    }
}
```

这种注解方式和通过配置文件的方式是功能完全相同的，可以减少xml配置文件出现过多的Bean节点

在获取对象的时候只要把getBean()方法中传入在类中注解的value值就可以获取对象了



### 14、分层注解

>在之前可以通过Component注解实现类的创建，但是为了更加直观的实现分层，Spring提供了不同层之间的注解

![屏幕快照 2019-08-19 上午11.25.10](/Users/tony/笔记/image/屏幕快照 2019-08-19 上午11.25.10.png)



### 15、通过注解实现依赖注入和属性注入

代码

```
/*
  <Bean name="CustomerService class="Tony.iggek6.CustomerService" >
        <property name="DAO" ref="CustomerDAO"></property>
  </Bean>
  与在配置文件中配置完全相同
* */
@Service(value = "CustomerService")
public class CustomerService {
    @Autowired
    private CustomerDAO DAO ;

    @Value("Tucker")
    private String name = "Tony";

    public void sean() {
        System.out.println("调用来CustomerService层");
        this.DAO.sean();
        System.out.println(this.name);
    }
}

--运行结果--
调用来CustomerService层
CustomerDAO层被调用
Tucker
```

>可以通过Autowired来注解属性，来完成注入，也可以通过Value的注解方式对简单类型的数据进行注入





###  16、依赖注入的四种方法

#### 		

#### 	1、通过@Autowired注解注入

		>这种注入会自动匹配配置中的BeanClass属性类型进行匹配

代码

```
@Autowired
private CustomerDAO DAO ;
```

​	

#### 	2、通过@Autowired + @Qualifier 注解注入

>这种注入会匹配id属性或者Component的name值来进行注入

代码

```
@Autowired
@Qualifier("DAO")
private CustomerDAO DAO ;
```

会自动匹配配置文件的Bean节点是否有id为DAO，或者通过Component的name值来进行注入



#### 	3、通过@Resource注解注入

>有两种写法，一种是直接@Recource注解，第二种是在@Resoutce(name="id") 加上Bean中ID
>
>第一种注入方式和直接使用@Autowired相同，通过类型匹配
>
>第二种注入方式和@Autowired + @Qualifier  方式相同，通过匹配ID注入

代码

第一种

```
@Resource
private CustomerDAO DAO ;
```

第二种

```
@Resource(name = "DAO")
private CustomerDAO DAO ;
```

#### 	

#### 	4、通过@InJect方式注入

>在使用Inject的时候需要先导入Inject的jar包

代码

第一种写法

```
@Inject
private CustomerDAO DAO ;
```

> 这种方式默认使用类型进行属性注入

第二种写法

```
@Inject
@Named("DAO")
private CustomerDAO DAO ;
```

>这种事通过ID进行注入依赖



#### PS：注意

在使用ID进行依赖注入的时候，如果输入的ID为红色标志表示没有找到相关ID的Bean

![屏幕快照 2019-08-19 下午12.14.19](/Users/tony/笔记/image/屏幕快照 2019-08-19 下午12.14.19.png)





### 17、使用注解指定init以及destroy方法

>在此之前是通过在配置文件中使用Bean的init-method与destroy-method属性指定类中的方法
>
>现在可以在需要让类中具体的方法为init或者destroy方法，只需要在类上注解就可以实现

代码

![屏幕快照 2019-08-19 下午4.20.26](/Users/tony/笔记/image/屏幕快照 2019-08-19 下午4.20.26.png)

```
@Component(value = "LifeCycleBean2")
public class LifeCycleBean2 {
    public LifeCycleBean2() {
        System.out.println("LifeCycleBean的构造方法被调用");
    }
    @PostConstruct
    public void init(){
        System.out.println("LifeCycleBean的Init方法被调用");
    }
    @PreDestroy
    public void destroy(){
        System.out.println("LifeCycleBean的destroy方法被调用");
    }
}
```

只要在方法上注解为@PostConstruct为init方法，@preDestroy为desctroy方法

--init方法为对象创建后调用
--destroy方法为销毁之前调用



### 18、通过注解配置类的作用域

> 之前是通过配置文件进行作用域的配置，现在可以通过@Scope注解完成

代码

```
@Scope("prototype")
public class LifeCycleBean2 {
    public LifeCycleBean2() {
        System.out.println("LifeCycleBean的构造方法被调用");
    }
}
```

通过@Scope注解设置作用域

在默认注解的情况下是单例设计模式，如果注解了@Scope("prototype")是多例设计模式





### 19、xml与注解的混合配置

>在实际开发中，一般往往会通过xml和注解混合配置，类的创建配置在Xml文件中，而属性的依赖通过注解完成

代码

```
public class ProductService {

    @Autowired
    private ProductDAO productDAO ;

    public void svan(){
        System.out.println("productService---层被调用");
        this.productDAO.svan();
    }
}
```

配置文件

```
<bean id="ProductDAO" class="Tony.igeek7.ProductDAO"/>
<bean id="ProductService" class="Tony.igeek7.ProductService"/>
```

这样做的好处是，在配置文件中配置类可以比较直观使用到了那些类，不会像注解那样太零散，在配置文件中就会比较集中一点，但是最终还是要看具体的要求



### 20、Spring到Junit测试集成

>可以通过注解的方式完成配置文件的加载
>
>需要导入Spring-text包ß

代码

```
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext3.xml")
public class ProductText {
    @Autowired
    private ProductService productService ;
    
    @Test
    public void Test2(){
        this.productService.sven();
    }
}
```

可以通过@Runwith与@contextConfiguration的注解实现配置文件的加载

#### Ps:注意

@Runwith与@ContextConfiguration注解需要有Spring-text的jar包依赖

spring-test需要的Junit是**org.junit.Test**，但是在@Test有两个包，另一个是**org.junit.jupiter.api.Test**，如果将**org.junit.Test**导错成了**org.junit.jupiter.api.Test**就会报java.lang.Exception: No runnable methods异常





### 21、Spring的AOP面向切面编程

>面向切面编程，是一种编程思想，是面向对象编程(OOP)的一种延续
>
>其中核心重点就是代理设计模式

![屏幕快照 2019-08-20 下午3.13.46](/Users/tony/笔记/image/屏幕快照 2019-08-20 下午3.13.46.png)

Target(目标对象):代理的目标对象

joinpoint(连接点):被代理中的所有方法为连接点

Pointcut(切入点):在连接点中选择需要代理的方法，这些代理方法就是切入点

Advice(通知):选择的代理方法，完成代理后的通知

​	--通知分为前置通知，后置通知，异常通知，最终通知，环绕通知(切面要完成的功能)

Aspect(切面): 切面=通知+切入点

Weaving(织入):是指把切面应用到目标对象来创建新的代理对象的过程.切面在指定的连接



### 22、JDK动态代理

>JDK动态代理的实现原理，就是通过把需要的代理的方法在不修改源代码的前提下，增加而外的一些方法

例子

Car类接口定义

![屏幕快照 2019-08-21 下午4.33.24](/Users/tony/笔记/image/屏幕快照 2019-08-21 下午4.33.24.png)

> 在这个接口中定义了两个方法

Car接口实现类

![屏幕快照 2019-08-21 下午4.34.11](/Users/tony/笔记/image/屏幕快照 2019-08-21 下午4.34.11.png)

>这个实现类写上具体的实现方法

CarLog类

![屏幕快照 2019-08-21 下午4.35.56](/Users/tony/笔记/image/屏幕快照 2019-08-21 下午4.35.56.png)

现在要求在不修改Car类代码的前提下，在Start方法运行完成之后运行CarLog.Log()方法

这个时候就会需要一个动态代理，Car就是代理对象



定义一个ProxyFactory的工厂代理

![屏幕快照 2019-08-21 下午4.49.24](/Users/tony/笔记/image/屏幕快照 2019-08-21 下午4.49.24.png)

>这个代理通过构造方法传递需要代理的对象
>
>在通过getProxyICar方法返回动态生成的代理对象
>
>在这个方法中，调用Proxy.newProxyInstance返回动态代理对象
>
>而这个Proxy.newProxyInstance需要传递一个InvocationHandler接口，实例这个InvocationHandler接口需要复写Invoke方法
>
>invoke方法是执行代理类中的任意方法都会执行的方法
>
>在这个方法里判断哪一些方法需要被代理，然后加入CarLog的log()方法执行
>
>在通过method.invoke执行原来的方法，如果写这句话，则原来的方法不会执行



测试类

![屏幕快照 2019-08-21 下午4.56.28](/Users/tony/笔记/image/屏幕快照 2019-08-21 下午4.56.28.png)

> 通过carProxyFactory.getProxyICar()放回代理后的Icar对象，在调用ICar方法就可以完成增加Carlog方法要求

运行结果

![屏幕快照 2019-08-21 下午4.58.17](/Users/tony/笔记/image/屏幕快照 2019-08-21 下午4.58.17.png)



### 23、Cglib动态代理

>Cglib代理与jdk动态代理是有一定区别，jdk动态代理只能代理实现接口的对象，而对于cglib可以代理没有实现接口的对象

例子

Commodity类

![屏幕快照 2019-08-22 上午11.53.08](/Users/tony/笔记/image/屏幕快照 2019-08-22 上午11.53.08.png)

>这是一个没有实现任何借口的普通类

CommodityLog类

![屏幕快照 2019-08-22 上午11.53.52](/Users/tony/笔记/image/屏幕快照 2019-08-22 上午11.53.52.png)

> 这也是一个普通的类，这个类是用于增强

现在的要求是在不修改源代码的情况下，在执行商品查询后打印日志信息



MethodFactory类的定义

![屏幕快照 2019-08-22 上午11.55.44](/Users/tony/笔记/image/屏幕快照 2019-08-22 上午11.55.44.png)

> 这个类通过构造方法接收需要代理的对象
>
> 在通过getCommodityProxy方法返回动态生成的代理对象
>
> ​		1、创建Enhancer对象 ，这是一个动态代理生成器
>
> ​		2、设置setClassLoader()，这里需要传递需要被代理类的加载器
>
> ​		3、设置setSuperclass()，这个方法需要传递被代理类的对象.class()
>
> ​		4、设置setCallback()，这个设置回调对象，传入的对象必须实现MethodInterceptor接口 由于本类实现了这个接口，所以传入了this
>
> ​		5、生成动态代理类create()方法
>
> 在类实现了MethodInterceptor接口需要复写Intercept方法，这个方法用于类每次调用方法的时候调用，在这个方法加入需要增强的方法，方法参数与jdk动态代理的invoke方法类似



测试代码

![屏幕快照 2019-08-22 下午12.03.24](/Users/tony/笔记/image/屏幕快照 2019-08-22 下午12.03.24.png)

运行结果

![屏幕快照 2019-08-22 下午12.04.01](/Users/tony/笔记/image/屏幕快照 2019-08-22 下午12.04.01.png)



#### Ps：注意

在Spring的AOP中，一般情况下都是用jdk的动态代理，但是也是需要看实际情况

如果类有实现接口选择jdk动态代理

如果类没有实现接口选择cglib动态代理



### 24、是用Spring的AOP动态代理(前置通知)

>在使用AOP之前需要先导入几个是使用到的依赖
>
>1、Spring-AOP
>
>2、aopalliance —AOP联盟
>
>3、aspectJ —面向切面的框架 需要导入aspectj-weaver的包

在Xml配置文件中需要导入一下的约束

```
xmlns:context="http://www.springframework.org/schema/aop"
xsi:schemaLocation="http://www.springframework.org/schema/aop
        http://www.springframework.org/schema/aop/spring-aop.xsd"
```



配置文件

```
<!-- 设置AOP代理 -->
<aop:config>
    <!-- 设置切入点 ID属性是定义切入点名称，exproession属性是定义需要代理的类 为BeanID-->
    <aop:pointcut id="pointcut1" expression="bean(*)"/> //这个*表示所有的类都进行拦截
    <!-- 设置切面 ref属性定义需要增强的类 这个类都是在IOC容器里的Bean中查询id-->
    <aop:aspect ref="PrintLog">
        <!-- 设置前置通知 method属性是设置增强类中的方法，pointcut-ref是指向切入点的iD-->
        <aop:before method="Log" pointcut-ref="pointcut1"/>
    </aop:aspect>
</aop:config>
```

​		pointcut-ref 和 ref 都是指向Bean中的ID，所以都需要在配置文件中把需要代理的类和增强的类配置Bean



测试类

```
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class AOPText {
		//属性注入
    @Autowired
    private ICar iCar ;
    
    //属性注入
    @Autowired
    private Commodity commodity;
    
    @Test
    public void Text(){
        iCar.start();
        iCar.end();
        
        commodity.save();
        commodity.find();
    }
}
```

#### Ps：注意

当配置完成之后，只要每次调用对象方法都会被代理



### 25、设置后置通知返回参数以及Joinpoint对象



#### 	1、joinpoint对象	

>org.aspectj.lang.JoinPoint对象是一个适用于面向切面编程的一个类
>
>joinpoint可以得到当前对象的、代理后的对象、可以当前的方法名称
>
>得到方法名称就可以选择指定方法进行代理

​	代码

```
public class PrintLog {
    public void StartLog(JoinPoint joinpoint){
        System.out.println("这是前置代理");
        System.out.println("方法名称：" + joinpoint.getSignature().getName());
        System.out.println("目标对象：" + joinpoint.getTarget().getClass().getName());
        System.out.println("代理对象：" + joinpoint.getThis().getClass().getName());
        // 获取getSignature().getName()这个返回的是方法名称
        if(joinpoint.getSignature().getName().equals("save")) {
            System.out.println("这个方法是Save！！！！！！！！！！！");
        }
    }
}
```

> 在增强的方法中传入Joinpoint的类型的参数

配置文件

```
<!-- 设置AOP代理 -->
<aop:config>
    <!-- 设置切入点 -->
    <aop:pointcut id="pointcut1" expression="bean(Commodity)"/>
    <!-- 设置切面 -->
    <aop:aspect ref="PrintLog">
        <!-- 设置通知 -->
        <aop:before method="StartLog"  pointcut-ref="pointcut1"/>
    </aop:aspect>
</aop:config>
```

测试代码

```
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext4.xml")
public class AOPText {
    @Autowired
    private ICar iCar ;
    @Autowired
    private Commodity commodity;

    @Test
    public void Text(){
        commodity.save();
        commodity.find();
    }
    @Test
    public void Text2(){

    }
}
```

允许结果

![屏幕快照 2019-08-23 下午4.51.39](/Users/tony/笔记/image/屏幕快照 2019-08-23 下午4.51.39.png)



#### 	2、设置后置通知

需要代理的类定义

```
public class Commodity {
    public String save() { //商品保存
        System.out.println("商品保存");
        return "这是save方法放回的参数！！！！";
    }
    public void find(){
        System.out.println("商品查询");
    }
}
```

配置文件

```
<!-- 设置AOP代理 -->
<aop:config>
    <!-- 设置切入点 -->
    <aop:pointcut id="pointcut1" expression="bean(Commodity)"/>
    <!-- 设置切面 -->
    <aop:aspect ref="PrintLog">
        <!-- 设置后置通知 -->
        <!-- method属性置顶增强的方法名称-->
        <!-- returning属性指定是返回参数与方法的放回值绑定-->
        <!-- pointcut-ref="pointcut1属性指定增强的类ID-->
        <aop:after-returning method="EndLog" returning="Temp" pointcut-ref="pointcut1"/>
    </aop:aspect>
</aop:config>
```

增强类的定义

```
public class PrintLog {
    public void EndLog(JoinPoint joinPoint,Object Temp){
        System.out.println("这是后置代理");
        if (joinPoint.getSignature().getName().equals("save")){
            System.out.println(Temp);
        }
    }
}
```

>针对save方法进行特殊代理代理，其中Temp为执行方法返回的参数，通过joinpoint对象判断类

测试代码

```
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext4.xml")
public class AOPText {
    @Autowired
    private ICar iCar ;
    
    @Autowired
    private Commodity commodity;

    @Test
    public void Text(){
        commodity.save();
        commodity.find();
    }
}
```

运行结果

![屏幕快照 2019-08-23 下午4.39.19](/Users/tony/笔记/image/屏幕快照 2019-08-23 下午4.39.19.png)





#### ps：注意

<aop:pointcut> 标签是设置切入点，也就是需要被代理的类

​		——ID 设置切入点名称 

​		——expression 设置切入点BeanID

<aop:aspect> 标签是设置切面标签

​		——ref 是设置增强类的Bean ID

​		<aop:before> 标签是设置前置标签

​				—— method属性是设置增强点方法

​				——pointcut-ref属性是设置增强类的ID，与aop:aspect的ref属性对应

​		<aop:after-returning> 标签是设置后置通知的标签，是有返回参数的

​				—— method属性是设置增强点方法

​				——returning属性是设置返回值名称，与增强类方法中的参数名称要一致

​				——pointcut-ref属性是设置增强类的ID，与aop:aspect的ref属性对应





### 26、环绕通知、异常通知、最终通知

#### 	1、环绕通知

>环绕通知，是可以设置前后通知，以及捕获异常，和最终通知所以需要重点掌握

增强类的代码

```
//环绕通知
public Object SurroundLog(ProceedingJoinPoint joinPoint) throws Throwable {
    System.out.println("--------开启事务--------");
    System.out.println(joinPoint.getSignature().getName());
    //执行当前对象的方法 返回参数为方法返回值，是什么就强制转换成什么
    Object object = joinPoint.proceed(); 
    System.out.println("--------关闭事务--------");
    return object ;
}
```

在增强类中定一个方法，这个方法接收ProceedingJoinPoint 类型的参数，该参数和Joinpoint参数使用基本类似

通过ProceedingJoinPoint类中有一个proceed方法，是执行当前方法，返回Object，此时的Object为方法放回值

在此时也可以通过try catch finally 设置捕获异常通知，最终通知

配置文件

```
<!-- 设置AOP代理 -->
<aop:config>
    <!-- 设置切入点 -->
    <aop:pointcut id="pointcut1" expression="bean(Commodity)"/>
    <!-- 设置切面 -->
    <aop:aspect ref="PrintLog">
        <!-- 环绕通知 method指定定义好的增强方法，pointcut-ref指定切入点-->
        <aop:around method="SurroundLog" pointcut-ref="pointcut1" />
    </aop:aspect>
</aop:config>
```



#### 		2、异常通知

>异常通知，是当方法执行出现异常或者在执行前置通知或者后置通知发生的异常，都会调用异常通知

代码

```
//异常通知
public void ExceptionLog(JoinPoint joinPoint,Throwable throwable){
    System.out.println("！！！发生异常！！！ 异常方法：" + joinPoint.getSignature().getName() + "，异常内容：" + throwable.getMessage());
}
```

在这个方法中接收两个参数，一个是Joinpoint可以获取当前对象以及执行的方法，throwable可以获取异常信息

throwable是error和Exception的父类

配置文件

```
<!-- 设置AOP代理 -->
<aop:config>
    <!-- 设置切入点 -->
    <aop:pointcut id="pointcut1" expression="bean(Commodity)"/>
    <!-- 设置切面 -->
    <aop:aspect ref="PrintLog">
    		<!-- 设置环绕通知 -->
        <aop:around method="SurroundLog" pointcut-ref="pointcut1" />
    		<!-- 设置异常通知 -->
    		<!-- methrod指向增强类中的异常通知方法 -->
    		<!-- throwing指向增强类中异常通知方法的Throwable参数名 -->
    		<!-- pointcut-ref指向切入点 -->
        <aop:after-throwing method="ExceptionLog" throwing="throwable" pointcut-ref="pointcut1" />
    </aop:aspect>
</aop:config>
```



### 3、最终通知

>最终通知的作用是不管方法是否产生了异常，都会进行通知

代码

```
//最终通知
public void AllLog(JoinPoint joinPoint) {
    System.out.println("最终通知！！不管是否有一异常都会被执行       方法名称：" + joinPoint.getSignature().getName());
}
```

>最终通知也是通过方法接收joinpoint的参数来获取当前对象的使用方法

配置文件

```
<!-- 设置AOP代理 -->
    <aop:config>
        <!-- 设置切入点 -->
        <aop:pointcut id="pointcut1" expression="bean(Commodity)"/>
        <!-- 设置切面 -->
        <aop:aspect ref="PrintLog">
            <!-- 环绕通知-->
            <aop:around method="SurroundLog" pointcut-ref="pointcut1" />
            <!-- 异常通知-->
            <aop:after-throwing method="ExceptionLog" throwing="throwable" pointcut-ref="pointcut1" />
            <!-- 最终通知-->
            <!-- method执行增强类中的最终通知方法 pointcut-ref指向切入点-->
            <aop:after method="AllLog" pointcut-ref="pointcut1" />
        </aop:aspect>
    </aop:config>
```



#### PS:注意

三种通知只要掌握了环绕通知即可，以为环绕通知可以在通知方法中加入try catch fallay这样一样可以达到捕获异常，指向最终通知的目的

Xml配置

最终通知：<aop:after> 

异常通知：<aop:after-throwing>

环绕通知：<aop:around>





### 27、AOP注解（前置通知）

>通过注解完成AOP配置，就不需要在applicationContext的配置文件中配置



#### 第一种实现方法

配置文件

```
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xmlns:aop="http://www.springframework.org/schema/aop"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd
        http://www.springframework.org/schema/context
        http://www.springframework.org/schema/context/spring-context.xsd
        http://www.springframework.org/schema/aop
        http://www.springframework.org/schema/aop/spring-aop.xsd">
    
    <context:component-scan base-package="com.tony" />
    <!-- 配置aop:aspectj的自动管理
            会自动扫描已有Bean，看那个Bean含有@Aspect注解，然后将有注解的Bean作为AOP管理，开启动态代理-->
    <aop:aspectj-autoproxy/>
    
</beans>
```

>在配置文件中需要配置AOP：aspectj-autoproxy的标签，这个标签可以将IOC容器中的Bean判断它们含有@Aspect注解，然后将有注解的Bean作为AOP管理

定义通知的类

```
@Component("Aspect") // 通知类也要配置Bean
@Aspect // AOP自动管理注解
public class MyAspect {
    @Before("bean(*)") // 需要代理的的类
    public void before(JoinPoint joinpoint){
        System.out.println("!!!!!前置通知!!!!!");
    }
}
```

> 在定义通知类的时候，需要将类注解为Aspect，这样spring就会自动将它作为AOP管理
>
> 定义一个方法注解为@Before，并传入需要代理的类，这样当类调用方法的时候都会先调用这个被注解了@before的方法



#### 第二种实现方法

> 在原来代码的基础上，可以做一些修改

修改通知类

```
@Component("Aspect")
@Aspect
public class MyAspect {

    @Pointcut("bean(Customer)")
    public void fun1(){}

    @Pointcut("bean(Product)")
    public void fun2(){}

    @Before("fun1()||fun2()")
    public void before(JoinPoint joinpoint){
        System.out.println("!!!!!前置通知!!!!!");
    }
}
```

> 这是第二种写法，定义一个没有方法体的方法，并注解为@Pointcut（切入点），并传入需要代理的类，在注解了@Before方法中传入方法名称就可以选择代理指定的类





### 28、AOP注解（后置通知、环绕通知、异常通知、最终通知）

>在学注解之前需要先了解一个表达式
>
>```
>//execution(* com.tony.service.*.*(..)) 
>表达式含义：任意放回值，在这个service包下的任意类的任意方法中任意参数都进行后置通知处理
>```
>
>这段表达式用于定位具体的代理包、类、方法
>
>第一个*号表示任意返回值
>
>第二段com.tony.service.* 	表示这个包下的所有类
>
>第三段.*(..)	表示这个包下的所有类的所有方法，同名方法的参数不同也都会被代理
>
>
>
>匹配所有类public方法  execution(public * *(..))
>匹配指定包下所有类方法 execution(* com.baidu.dao.*(..)) 不包含子包
>execution(* com.baidu.dao..*(..))  ..*表示包、子孙包下所有类
>匹配指定类所有方法 execution(* com.baidu.service.UserService.*(..))
>匹配实现特定接口所有类方法execution(* com.baidu.dao.GenericDAO+.*(..))
>匹配所有save开头的方法 execution(* save*(..))

​		

#### 1、后置通知

增强类的定义

```
//后置通知
//execution(* com.tony.service.*.*(..)) 表达式含义：任意放回值，在这个service包下的任意类的任意方法中任意参数都进行后置通知处理
@AfterReturning(value = "execution(* com.tony.service.CustomerImpl.find(..))",returning = "vo")
public void AfterReturning(JoinPoint joinPoint,Object vo){
    if (vo != null){ //判断是否有返回值
        System.out.println();
        System.out.println(vo);
    } else {
        System.out.println();
        System.out.println("没有接收到参数");
    }
    System.out.println("后置通知!!!!!!!!!!!! ");
}
```

> 在这个后置通知中要对方法注解@AfterReurning注解还需要传递两个参数，一个是需要代理的类，第二个是返回值，对呀方法的Object参数



#### 2、环绕通知

增强类的定义

```
//环绕通知
//execution(* com.tony.service.ProductService.find(..))
// 表示：任意返回值，代理com.tony.service.ProductService类中定义的任意参数的find方法
@Around("execution(* com.tony.service.ProductService.find(..))")
public Object Around(ProceedingJoinPoint proceedingJoinPoint) throws Throwable{
    System.out.println("环绕通知------前");
    Object object = proceedingJoinPoint.proceed(); // 执行方法，返回Object
    if (object !=null ){ //判断返回参数
        System.out.println((Boolean) object);
    }
    proceedingJoinPoint.getSignature().getName(); 取得当前执行方法的名称ß
    System.out.println("环绕通知------后");
    return object ; // 需要将方法返回的参数在返回出去，不然会出现异常
}
```

> 通过注解完成环绕通知，和配置文件相同
>
> 对要增强方法注解@Around,并传递需要代理的类或者方法通过表达式完成
>
> 定义的方法需要接收ProceedingJoinpoint参数以及抛出Throwable
>
> 定义的方法一定有返回值，返回执行方法后返回的Object参数
>
> 取得方法名称方法 proceedingJoinPoint.getSignature().getName() 



#### 3、异常通知

增强类定义

```
//异常通知
// 当目标对象发生异常，都会触发异常通知
@AfterThrowing(value = "execution(* com.tony.service.*.*(..))",throwing = "ex")
public void AfterThrowing(JoinPoint joinPoint,Throwable ex){
    System.out.println("！！！！出现异常！！！"+joinPoint.getSignature().getName() + ex.getMessage());
}
```

> 在增强类中定一个方法，这个方法注解为@AfterThrowing，并传入需要代理的包、或者类、或者是方法，当被代理的类发生了异常，就会执行这个异常通知
>
> 在@AfterThrowing注解中的Throwing参数是传递方法定义的异常名称



#### 4、最终通知

增强类的定义

```
//定义最终通知
//无论执行的方法是否有异常，都会执行
@After("execution(* com.tony..*(..))")
public void After(JoinPoint joinPoint){
    System.out.println("------------------最终通知------------------");
}
```

> 最终通知，当执行的方法执行完毕之后，无论是否发生了异常都会进行最终的通知



#### 扩展

>当一个实现类实现类某一个接口的时候，由于需要扩展而外的方法，此时实现类写入了自己的方法，这样会造成默认是使用JDK动态代理的AOP报错，因为在这个接口中没有定义实现类自己定义的方法

例子：

```
public class CustomerImpl implements ICustomer{

    @Autowired
    private User vo ;

    @Override
    public void save(User user) {
        System.out.println(user);
        System.out.println("用户已保存");
    }

    @Override
    public User find() {
        System.out.println("查询到结果");
        this.vo.setName("Tony");
        this.vo.setAge(25);
        this.vo.setSal(5999.55);
        return vo ;
    }

    public void update(){
        System.out.println("客户更新****");
    }
}
```

> 这个类实现类ICustomer接口，并且复写了接口中的两个方法，现在在这个实现类中有新增加了一个Update的方法，这个方法并没有在接口中定义，所以如果使用默认的JDK动态代理，代理类会自动转型成接口，转型成接口后就不能在转回成实现类，所以为了解决这个问题，可以在配置文件中配置

```
<!-- 配置aop:aspectj的自动管理
        会自动扫描已有Bean，看那个Bean含有@Aspect注解，然后将有注解的Bean作为AOP管理，开启动态代理-->
<!-- 配置 Proxy-target-class 属性为true表示使用cglib动态代理
       在Spring中，AOP的处理机制是默认是使用的是JDK动态代理，所以此属性默认为False
-->
<aop:aspectj-autoproxy proxy-target-class="true"/>
```

> 在配置文件中，为aop:aspectj-autoproxy标签配置proxy-target-class属性，这个属性表示，使用Cglib动态代理，这样就可以让AOP完成代理类后不会转型成接口，就可以调用实现类中自定增加方法。





### 29、JdbcTemplate的使用

>在使用JdbcTemplate的时候，需要导入一下Jar包
>
>1、数据库驱动
>
>2、spring-jdbc
>
>3、spring-tx

例子

![屏幕快照 2019-08-29 上午11.22.34](/Users/tony/笔记/image/屏幕快照 2019-08-29 上午11.22.34.png)

代码

```
public class jdbcText {
    @Test
    public void Text(){
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
        dataSource.setUrl("jdbc:oracle:thin:@192.168.0.107:1521:oracle");
        dataSource.setUsername("c##WEB");
        dataSource.setPassword("admin123");

				
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        jdbcTemplate.execute("CREATE TABLE test001(id int,name VARCHAR2(50))");


        System.out.println(jdbcTemplate);

    }
}
```

> 获取到的jdbctemplate可以执行sql命令，从而操作数据库





### 30、三种连接池

#### 	

#### 	1、Spring内置连接池

>通过Spring内置的连接池可以完成数据库的连接

配置文件

```
<!-- Spring内置数据源-->
<bean id="dataSource" class="org.springframework.jdbc.datasource.DriverManagerDataSource" >
    <property name="driverClassName" value="oracle.jdbc.driver.OracleDriver" />
    <property name="url" value="jdbc:oracle:thin:@192.168.0.107:1521:oracle"/>
    <property name="username" value="c##WEB" />
    <property name="password" value="admin123"/>
</bean>

 <bean id="JdbcTemplate" class="org.springframework.jdbc.core.JdbcTemplate" >
        <property name="dataSource" ref="dataSource" />
    </bean>
```

> 通过配置org.springframework.jdbc.datasource.DriverManagerDataSource类，并将四个参数通过property标签注入进去，在通过Bean标签实例化
>
> 然后通过Bean实例化JdbcTemplate，并将生成好的DriverManagerDataSource注入到JdbcTemplate的dataSource属性中

测试代码

```
@Autowired
private JdbcTemplate jdbcTemplate;

@Test
public void Text(){
    this.jdbcTemplate.execute("CREATE TABLE test005(id int,name VARCHAR2(50))");
    System.out.println(this.jdbcTemplate);
}
```

>  通过Autowired注解，注入jdbcTemplate属性，在使用jdbcTemplate属性调用sql语句



#### 	2、Apache DBCP 数据源

> 这由Apache提供的一组数据源操作包
>
> 需要导入一下jar包
>
> —org.apache.commons.commons.dbcp.jar
>
> —org.apache.commons.commons.pool.jar

配置文件

```
<!-- Apache DBCP数据源-->
<bean id="dataSource2" class="org.apache.commons.dbcp2.BasicDataSource">
    <property name="driverClassName" value="oracle.jdbc.driver.OracleDriver" />
    <property name="url" value="jdbc:oracle:thin:@192.168.0.107:1521:oracle"/>
    <property name="username" value="c##WEB" />
    <property name="password" value="admin123"/>
</bean>

<bean id="JdbcTemplate" class="org.springframework.jdbc.core.JdbcTemplate" >
        <property name="dataSource" ref="dataSource2" />
    </bean>
```

> 通过配置org.apache.commons.dbcp2.BasicDataSource类，并将四个参数通过property标签注入进去，在通过Bean标签实例化
>
> 然后通过Bean实例化JdbcTemplate，并将生成好的DriverManagerDataSource注入到JdbcTemplate的dataSource属性中

测试代码

```
@Autowired
private JdbcTemplate jdbcTemplate;

@Test
public void Text2(){
    this.jdbcTemplate.execute("CREATE TABLE test005(id int,name VARCHAR2(50))");
    System.out.println(this.jdbcTemplate);
}
```

> 测试代码不变，通用是通过注入属性取得JdbcTemplate



#### 	3、C3P0 数据源

>C3P0数据源需要导入一下jar包
>
>—com.mchange.c3p0.jar

配置文件

```
<!-- C3P0 数据源-->
<bean id="dataSource3" class="com.mchange.v2.c3p0.ComboPooledDataSource">
    <property name="driverClass" value="oracle.jdbc.driver.OracleDriver"/>
    <property name="jdbcUrl" value="jdbc:oracle:thin:@192.168.0.107:1521:oracle"/>
    <property name="user" value="c##WEB"/>
    <property name="password" value="admin123" />
</bean>

<bean id="JdbcTemplate" class="org.springframework.jdbc.core.JdbcTemplate" >
    <property name="dataSource" ref="dataSource3" />
</bean>
```

> 通过配置com.mchange.v2.c3p0.ComboPooledDataSource类，并将四个参数通过property标签注入进去，在通过Bean标签实例化，注意此时的四个参数和DBCP、内置数据源参数名称不同，需要注意
>
> 然后通过Bean实例化JdbcTemplate，并将生成好的DriverManagerDataSource注入到JdbcTemplate的dataSource属性中

测试代码

```
@Autowired
private JdbcTemplate jdbcTemplate;

@Test
public void Text2(){
    this.jdbcTemplate.execute("CREATE TABLE test005(id int,name VARCHAR2(50))");
    System.out.println(this.jdbcTemplate);
}
```

> 测试代码不变，通用是通过注入属性取得JdbcTemplate





### 31、外部属性文件配置连接

>在实际操作中，如果把用户名密码直接通过配置在Xml文件中，会造成耦合度高，更换数据库的时候麻烦，所以一般都会使用一个property文件来配置连接路径、用户名、密码

Jdbc.property文件

```
jdbc.class=com.mchange.v2.c3p0.ComboPooledDataSource
jdbc.url=jdbc:oracle:thin:@192.168.0.107:1521:oracle
jdbc.username=c##WEB
jdbc.password=admin123
```

在配置applicationContext.xml文件中引用配置

```
<!-- 引用配置文件-->
<context:property-placeholder location="jdbc.properties" />

<!-- 定义dataSource-->
<bean id="dataSource4" class="${jdbc.class}" >
    <property name="jdbcUrl" value="${jdbc.url}" />
    <property name="user" value="${jdbc.username}"/>
    <property name="password" value="${jdbc.password}"/>
</bean>

<bean id="JdbcTemplate" class="org.springframework.jdbc.core.JdbcTemplate" >
    <property name="dataSource" ref="dataSource4" />
</bean>
```

测试代码

```
@Autowired
private JdbcTemplate jdbcTemplate;

@Test
public void Text2(){
    this.jdbcTemplate.execute("CREATE TABLE test006(id int,name VARCHAR2(50))");
    System.out.println(this.jdbcTemplate);
}
```

> 测试代码不变，通用是通过注入属性取得JdbcTemplate



### 32、JdbcTemplate 增加数据

> ```
> org.springframework.jdbc.core.support.JdbcDaoSupport
> ```
>
> 使用JdbcTemplate增删改查时候，需要先让DAO类的类继承JdbcDaoSupport，这个JdbcDaosupport会自动注入DataSource属性，所以在配置Bean的时候直接配置perproty标签就可以，

配置文件

```
<bean id="CarDAO" class="com.temp3.CarDAO" >
    <property name="dataSource" ref="dataSource2" />
</bean>
```

> 应为此类继承了JdbcDaoSupport，所以可以通过property标签注入父类的dataSource

定义DAO层

```
public class CarDAO extends JdbcDaoSupport {
    public void save(Car car){
    		//此处使用了序列，IDADD是已经定义了序列
        String sql = "INSERT INTO TextCar(id,name,PRICE) VALUES (IDADD.nextval,?,?)"; 
        JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
        jdbcTemplate.update(sql,car.getName(),car.getPrice()) ;
    }
}
```

> 并且通过调用父类中的getJdbcTemplate()方法返回jdbcTemplate，在调用jdbcTemplate的Update方法操作数据库
>
> 当调用update的时候，只需要传递sql语句和需要的参数（也就是sql语句中的问号的参数）
>
> 这里操作的是数据库的插入数据的操作，删除、更新的操作都是一样的，只需要修改需要执行的语句

测试方法

```
public class jdbcTemplateCRUDText {

    @Test
    public void text(){
        ApplicationContext applicationContext = new 		ClassPathXmlApplicationContext("applicationContext.xml"); // 加载ApplicationContext配置文件
        Car car = (Car) applicationContext.getBean("VoCar"); // 取得Bean对象
        car.setName("911"); 
        car.setPrice(9999.9);
        CarDAO carDAO = (CarDAO) applicationContext.getBean("CarDAO"); // 取得Bean对象
        carDAO.save(car); // 保存数据
    }
}
```

### 

### 33、Jdbctemplate查询数据

#### 		1、查询单条记录

> 使用JdbcTemplate插叙数据，需要借助一个RowMapper接口
>
> 首先需要让一个类实现这个接口，复写其中的mapRow(ResultSet result,int i ) throws SQLException 方法
>
> 这个接口也有一个范型，所指定的范型就是返回的数据类型
>
> 所查询的数据是直接返回数据类的

配置文件

```
<bean id="CarDAO" class="com.temp3.CarDAO" >
    <property name="dataSource" ref="dataSource2" />
</bean>
```

> CarDao已经实现了JdbcDaoSupport的接口，所以可以直接注入dataSource属性

CarRowMapper 类定义

```
public class CarRowMapper implements RowMapper<Car> {
    @Override
    public Car mapRow(ResultSet resultSet, int i) throws SQLException {
        Car car = new Car() ;
        car.setId(resultSet.getInt(1));
        car.setName(resultSet.getString(2));
        car.setPrice(resultSet.getDouble(3));
        return car;
    }
}
```

当查询到数据的时候，每查询到一条数据都会执行其中的mopRow方法，然后加入自己的逻辑完成数据的保存，返回包装好的对象出去

CarDao定义

```
public class CarDAO extends JdbcDaoSupport {
    public Car funByid(Integer id) {
        Car car = null ;
        String sql = "SELECT * FROM TEXTCAR WHERE id = ? " ;
        JdbcTemplate jdbcTemplate = this.getJdbcTemplate() ;
        try{
            car = jdbcTemplate.queryForObject(sql,new CarRowMapper(),id);
        } catch(Exception e){
            return null ;
        }
        return car ;
    }
}
```

> 定义了一个funByid的方法，通过查询id查询记录，通过jdbcTemplate.queryForObject()方法可以进行单独数据的查询，如果没有查询结果会抛异常，所以可以捕获异常来解决，如果没有查询到数据，捕获异常返回null

测试类

```
@Test
public void text2(){
    ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
    CarDAO carDAO = (CarDAO) applicationContext.getBean("CarDAO") ;
    Car car = carDAO.funByid(1);
    System.out.println(car);
}
```



#### 2、多条记录的查询

> 多条记录查询相和单挑记录一样

CarRowMapper类定义

```
public class CarRowMapper implements RowMapper<Car> {
    @Override
    public Car mapRow(ResultSet resultSet, int i) throws SQLException {
        Car car = new Car() ;
        car.setId(resultSet.getInt(1));
        car.setName(resultSet.getString(2));
        car.setPrice(resultSet.getDouble(3));
        return car;
    }
}
```

>  此处的CarRowMapper和单条记录的查询是一样定义方法，原理都是通过遍历查询结果

CarDao类定义

```
public class CarDAO extends JdbcDaoSupport {
    public List<Car> queryAll(){
        JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
        String sql = "SELECT id,name,price FROM TextCar";
        List<Car> list = jdbcTemplate.query(sql,new CarRowMapper());
        return list ;
    }
}
```

> 和单挑记录一样的，不过单挑记录使用的方法是queryForObject，而如果查询多条记录使用query方法
>
> query方法返回的是List集合类型由CarRowMapper所以继承的RowMapper范型决定

测试类

```
@Test
public void Text3(){
    ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
    CarDAO carDAO = (CarDAO) ac.getBean("CarDAO");
    List<Car> list = carDAO.queryAll();
    for(Car vo : list){
       System.out.println(vo + "\n");
    }
}
```

> 测试方法一样，通过迭代输出lIst集合取得内容

### 

### 34、事务隔离级别

#### 	1、事务的基本要素（ACID）

> 　　1、原子性（Atomicity）：事务开始后所有操作，要么全部做完，要么全部不做，不可能停滞在中间环节。事务执行过程中出错，会回滚到事务开始前的状态，所有的操作就像没有发生一样。也就是说事务是一个不可分割的整体，就像化学中学过的原子，是物质构成的基本单位。
>
> 　　 2、一致性（Consistency）：事务开始前和结束后，数据库的完整性约束没有被破坏 。比如A向B转账，不可能A扣了钱，B却没收到。
>
> 　　 3、隔离性（Isolation）：同一时间，只允许一个事务请求同一数据，不同的事务之间彼此没有任何干扰。比如A正在从一张银行卡中取钱，在A取钱的过程结束前，B不能向这张卡转账。
>
> 　　 4、持久性（Durability）：事务完成后，事务对数据库的所有更新将被保存到数据库，不能回滚。
>
> 

#### 	2、事务的并发问题

> ​		1、脏读：事务A读取了事务B更新的数据，然后B回滚操作，那么A读取到的数据是脏数据
>
> 　　2、不可重复读：事务 A 多次读取同一数据，事务 B 在事务A多次读取的过程中，对数据作了更新并提交，导致事务A多次读取同一数据时，结果 不一致。
>
> 　　3、幻读：系统管理员A将数据库中所有学生的成绩从具体分数改为ABCDE等级，但是系统管理员B就在这个时候插入了一条具体分数的记录，当系统管理员A改结束后发现还有一条记录没有改过来，就好像发生了幻觉一样，这就叫幻读。
>
> 　　小结：不可重复读的和幻读很容易混淆，不可重复读侧重于修改，幻读侧重于新增或删除。解决不可重复读的问题只需锁住满足条件的行，解决幻读需要锁表



#### 	3、事务隔离级别	

> ​																脏读		不可重复读		幻读
> 读未提交		（read-uncommitted）		是				是				是
> 不可重复读	（read-committed）			否				是				是
> 可重复读		（repeatable-read）			否				否				是
> 串行化			（serializable）					否				否				否



#### 	PS：注意

> ​		1、事务隔离级别为读提交时，写数据只会锁住相应的行
>
> 　　2、事务隔离级别为可重复读时，如果检索条件有索引（包括主键索引）的时候，默认加锁方式是next-key 锁；如果检索条件没有索引，更新数据时会锁住整张表。一个间隙被事务加了锁，其他事务是不能在这个间隙插入记录的，这样可以防止幻读。
>
> 　　3、事务隔离级别为串行化时，读写数据都会锁住整张表
>
> 　　 4、隔离级别越高，越能保证数据的完整性和一致性，但是对并发性能的影响也越大。



### 	35、事务的传播行为	

>  事务的7种传播行为
>
> 1、>PROPAGATION_REQUIRED:支持当前事务，假设当前没有事务。就新建一个事务。
>
> 2、PROPAGATION_SUPPORTS:支持当前事务，假设当前没有事务，就以非事务方式运行。
>
> 3、PROPAGATION_MANDATORY:支持当前事务，假设当前没有事务，就抛出异常。 
>
> 4、PROPAGATION_REQUIRES_NEW:新建事务，假设当前存在事务。把当前事务挂起。
>
> 5、PROPAGATION_NOT_SUPPORTED:以非事务方式运行操作。假设当前存在事务，就把当前事务挂起。
>
> 6、PROPAGATION_NEVER:以非事务方式运行，假设当前存在事务，则抛出异常。
>
> 7、PROPAGATION_NESTED:如果当前存在事务，则在嵌套事务内执行。如果当前没有事务，则进行与PROPAGATION_REQUIRED类似的操作。

#### 	PS:注意

> 所以事务也就是相当于Service层中的方法就是事务，准确来说应该AOP动态代理设置的切入点
>
> 以上所说的没有事务表示Service层的方法中没有调用DAO层，这个就相当于没有存在事务

### 36、Spring事务配置方法

#### 		1、xml方式配置

> 使用spring中的事务管理器来管理事务 
>
> spring事务管理器：org.springframework.jdbc.datasource.DataSourceTransactionManager
>
> 所谓事务管理就是可以保证数据的一致性，比如在一个Service的方法中，需要调用DAO层的两个原子性操作（例如转账，转出和转入两个操作），所以为了保证两个原子性操作能够同时完成，如果有一个执行失败，那么数据应该回滚，所以现在由spring的事务管理器来做这一件事

下面使用一个转账的例子

> 这个例子需要使用AOP的动态代理，所以需要导入AOP相关的jar包

数据表结构

iD	名称		金额

1	Tony		10000
2	Tucker	 10000



定义一个IAccountDao接口

```
public interface IAccountDao {

    public void in(String name,Double money); //实现转入的的操作
    public void out(String name , Double mpney); //实现转出的操作
}
```

定义AccountDaoImpl，实现IAccountDao接口

```
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class AccountDaoImpl extends JdbcDaoSupport implements IAccountDao{
    @Override
    public void in(String name, Double money) {
        String sql = "UPDATE accountmoney Set money1 = money + ? WHERE name = ? " ;
        this.getJdbcTemplate().update(sql,money,name) ; // 执行sql语句
    }
    @Override
    public void out(String name, Double money) {
        String sql = "UPDATE accountmoney SET money = MONEY - ? WHERE name = ?" ;
        this.getJdbcTemplate().update(sql,money,name); //执行sql语句
   }
}
```

> 此类除了需要实现IAccountDao接口之外，还需要继承JdbcDaoSupport类，使用Dao管理模板
>
> 复写接口定义的方法，并实现具体的操作

定义IAccountService接口

```
public interface IAccountService {
		//转账的操作
    public boolean savetransferMoney(String inName,String outName,Double Money) ; 
}
```

> 此接口定义了一个方法，这个方法用于转账，需要传入转账人、接受人、金额

定义AccountServiceImpl，实现IAccountService接口

```
public class AccountServiceImpl implements IAccountService{

    private IAccountDao accountDao ; // 需要写set、get方法，用于属性注入
    public IAccountDao getAccountDao() {
        return accountDao;
    }
    public void setAccountDao(IAccountDao accountDao) {
        this.accountDao = accountDao;
    }   

    @Override
    public boolean savetransferMoney(String inName, String outName, Double money) { //转账操作
        this.accountDao.out(outName,money); // 调用DAO中的方法
        this.accountDao.in(inName,money); //调用DAO中的方法
        return true ; // 返回true
    }
}
```

> 这个类实现了具体的转账操作，转账操作就是调用一个转出一个转入

定义Jdbc.properties文件

```
jdbc.classDriver = oracle.jdbc.driver.OracleDriver
jdbc.url = jdbc:oracle:thin:@192.168.63.128:1521:oracle
jdbc.username = c##Web  
jdbc.password = admin123 
```

xml文件配置

```
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:aop="http://www.springframework.org/schema/aop"
       xmlns:tx="http://www.springframework.org/schema/tx"
       xmlns:context="http://www.springframework.org/schema/context"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
                            http://www.springframework.org/schema/beans/spring-beans.xsd
                            http://www.springframework.org/schema/aop
                            http://www.springframework.org/schema/aop/spring-aop.xsd
                            http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd
                            http://www.springframework.org/schema/tx
                            http://www.springframework.org/schema/tx/spring-tx.xsd
">
        
        <!-- 导入Jdbc.properties属性文件-->
        <context:property-placeholder location="jdbc.properties"/>
    
        <!-- 配置datasource，这里使用c3p0的连接池-->
        <bean id="datasource" class="com.mchange.v2.c3p0.ComboPooledDataSource" >
            <property name="driverClass" value="${jdbc.classDriver}" />
            <property name="jdbcUrl" value="${jdbc.url}" />
            <property name="user" value="${jdbc.username}" />
            <property name="password" value="${jdbc.password}" />
        </bean>

    <!-- 定义AccountDAO-->
    <bean id="AccountDao" class="com.temp4.AccountDaoImpl" >
        <!-- 注入属性datasource属性-->
        <property name="dataSource" ref="datasource" />
    </bean>

    <!-- 定义AccountService-->
    <bean id="AccountService" class="com.temp4.AccountServiceImpl" >
        <!-- 注入Dao属性-->
        <property name="accountDao" ref="AccountDao" />
    </bean>
	
		<!-- 第一步-->
    <!-- 定义一个事务平台管理器(DataSource管理器)-->
        <bean id = "transactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
            <!-- 注入数据源-->
            <property name="dataSource" ref="datasource" />
        </bean>
        
		<!-- 第二步-->
    <!-- 定义AOP通知 通知中要处理的就是事务
        id —— 为通知起一个ID
        transaction-manager —— 指定DataSource管理器ID    -->
    <tx:advice id="txAccount" transaction-manager="transactionManager">
        <!-- 配置事务的属性定义-->
        <tx:attributes>
            <!-- 配置具体的事务方法和事务属性
                name —— 配置具体的方法名称，有下面的aop定义具体的类
                isolation —— 事务的隔离级别，默认按数据库的隔离级别
                propagation —— 事务的传播行为，默认是同一个事务，相当于service层中的方法，如果这个方法没有调用DAO，则表示没有事务
                timeout —— 事务的超时时间，默认使用数据库的超时时间
                read-only —— 事务是否只读，true表示只读，false表示可读写，默认是可读写
            -->
            <tx:method name="save*" isolation="READ_COMMITTED" propagation="REQUIRED" timeout="-1" read-only="false"/>
            <!-- 可以配置成通配符，也就表示对update、delete、find开头的方法进行事务代理-->
            <tx:method name="update*" />
            <tx:method name="delete*" />
            <!-- 应为find开头的方法多数为查询方法，所有事物只读设置为true-->
            <tx:method name="find*" read-only="true"/>
        </tx:attributes>
    </tx:advice>

		<!-- 第三步-->
    <!-- 设置AOP代理-->
    <aop:config >
        <!-- 设置切入点
            id —— 配置一个切入点ID
            expression —— 配置需要代理的类 -->
        <aop:pointcut id="txPointcut" expression="bean(*Service)"/>
        <!-- 设置切面
            advice-ref —— 配置事务管理器的通知的ID
            pointcut-ref —— 配置切入点ID
        -->
        <aop:advisor advice-ref="txAccount" pointcut-ref="txPointcut" />
    </aop:config>
    
</beans>
```

> 在这个配置文件中，主要的核心操作就是首先配置
>
> 第一步：配置事务管理器的Bean（DataSourceTransactionManager）并且需要注入datasource属性
>
> 第二步：配置一个通知，使用 <tx:advic>标签实现
>
> ​		在这个标签中需要指定创建好的事务管理器的ID，以及设置管理模式和需要管理的方法
>
> 第三步：配置一个AOP代理，设置切入点、切面，切面指向刚刚配置好的通知

测试类

```
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext3.xml")
public class Test {

    @Autowired
    private IAccountService accountService ;

    @org.junit.Test
    public void test(){
   			 this.accountService.savetransferMoney("Tony","Tucker",1000D） // 调用Service层方法
    }
}
```

> 调用Service层方法



#### 2、注解方式

定义AccountDaoimpl定义

```
@Repository("accountDao2")
public class AccountDaoImpl extends JdbcDaoSupport  {

		//注入datasource属性，此属性来自父类的JdbcDaoSupport
    @Autowired
    public void setDi(DataSource dataSource){
        super.setDataSource(dataSource);
    }
    
		//用于查询的RowMapper内置对象
    public class AccountRowMap implements RowMapper<AccountUser>{
        @Override
        public AccountUser mapRow(ResultSet resultSet, int i) throws SQLException {
            AccountUser vo = new AccountUser();
            vo.setId(resultSet.getInt(1));
            vo.setName(resultSet.getString(2));
            vo.setMoney(resultSet.getDouble(3));
            return vo;
        }
    }
	
    public void saveInMoney(String name, Double money) {
        String sql = "UPDATE AccountMoney Set money = money + ? WHERE name = ?" ;
        this.getJdbcTemplate().update(sql,money,name);
    }

    public void saveOutMoney(String name, Double money) {
        String sql = "UPDATE AccountMoney SET money = money - ? WHERE name = ?" ;
        this.getJdbcTemplate().update(sql,money,name);

    }

    public AccountUser funName(String name) {
        String sql = "SELECT id,name,money FROM AccountMoney WHERE name = ? ";
        List<AccountUser> list =  this.getJdbcTemplate().query(sql,new AccountRowMap(),name);
        AccountUser vo = list.get(0);
        return vo ;
    }
}
```

> 在这个dao层中实现了三个方法，分别是转出、转入、查询，其中AccountRowMapper是用于查询的内置对象



定义AccountServiceImpl

```
@Service("AccountService2")
/* 当配置文件中配置好了<tx:annotation-driven transaction-manager="AccountTransactionManager"/> spring会自动加载
    注解在类上表示对这个类的所有方法使用事务管理
* */
@Transactional(isolation = Isolation.READ_COMMITTED,timeout = -1,propagation = Propagation.REQUIRED,readOnly = false) // 可以传入相应的设置参数
public class AccountServiceImpl  {

    @Resource(name = "accountDao2")
    private AccountDaoImpl accountDao ;

    public void setAccountDao(AccountDaoImpl accountDao) {
        this.accountDao = accountDao;
    }

    public void saveTransfer(String inName, String outName, Double money) {
        this.accountDao.saveOutMoney(outName,money);
        this.accountDao.saveInMoney(inName,money);
    }


    //也可注解在指定的方法上，对单个方法使用事务管理
    @Transactional(readOnly = true)
    public AccountUser findUser(String name) {
        return (AccountUser) this.accountDao.funName(name);
    }
}
```

> 在这个Service层中定义两个事务，分别是转账、以及查询，其中转账的操作分别调用DAO层的转出和转入
>
> 重点为@Transactional注解，此注解为对指定的类或者方法进行事务管理
>
> 如果注解在类上，表示对该类的所有方法都是实现事务管理，注解在方法上表示对单个方法进行事务管理
>
> 在这个@Transactional注解之中可以传递各个事务模式的配置，事务隔离，传播行为，指定，超时时间等等

配置文件

```
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xmlns:bean="http://www.springframework.org/schema/context" xmlns:tx="http://www.springframework.org/schema/tx"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd http://www.springframework.org/schema/tx http://www.springframework.org/schema/tx/spring-tx.xsd">
		
		<!-- 导入资源文件-->
    <context:property-placeholder location="jdbc.properties"/>
    <!-- 配置数据源-->
    <bean id="dataSource" class="com.mchange.v2.c3p0.ComboPooledDataSource">
        <property name="driverClass" value="${jdbc.driverClass}"/>
        <property name="jdbcUrl" value="${jdbc.url}"/>
        <property name="user" value="${jdbc.user}"/>
        <property name="password" value="${jdbc.password}" />
    </bean>

    <!-- 创建事务管理器，并注入datasource参数-->
    <bean id="AccountTransactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager" >
        <property name="dataSource" ref="dataSource"/>
    </bean>

    <!-- 启用Bean注解扫描-->
    <bean:component-scan base-package="com2.*"/>

    <!-- 事务注解驱动会对，会自动识别事务注解，指向创建好的DataSourceTransactionManager-->
    <tx:annotation-driven transaction-manager="AccountTransactionManager"/>

</beans>
```

> 在配置文件中，配置了<tx:annotation-driven transaction-manager="AccountTransactionManager"/>，就会自动扫面注解了@Transactional注解的类或者方法

测试类

```
import com.service.IAccountService;
import com2.dao.AccountDaoImpl;
import com2.service.AccountServiceImpl;
import com2.vo.AccountUser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext2.xml")
public class TestAccount {

		//注入Service层属性
    @Resource(name = "AccountService2")
    private AccountServiceImpl accountService2  ;

    @Test
    public void Test2(){
        this.accountService2.saveTransfer("Tucker","Tony",1000D); // 调用转帐
        System.out.println(this.accountService2.findUser("Tucker")); // 查询
        System.out.println(this.accountService2.findUser("Tony")); //查询
    }
}
```



#### PS：小结

> Spring的事务管理主要有一下几个步骤
>
> xml文件配置
>
> 1、配置数据源(DataSource)
>
> 2、定义好JdbcDaoSupport类的模板，并且注入DataSource数据源属性，(也可以自己创建JdbcTemplate)
>
> 3、在配置文件中配置好事务管理器，也就是DataSourceTransactionManager，并且也需要注入数据源
>
> 4、定义好Service层调用DAO层的类，每一个Service层的方法都算是一个事务
>
> 5、在配置文件中定义事务管理通知，也就是需要什么方法进行增益，配置事务管理模式，通过<x:advice>标签配置
>
> 6、在配置文件中，定义一个AOP代理<aop:config>，配置切入点（也就是Service层）然后在通过<aop:advisor>引入事务管理的通知
>
> 之后只要调用Service层的事务，spring都会自动代理配置好的方法进行事务管理
>
> 
>
> 注解配置
>
> 1、在配置文件中配置数据源(DataSource)
>
> 2、在配置文件中配置好事务事务管理器DataSourceTransactionManager，并且需要注入dataSource
>
> 3、定义好JdbcDaoSupport类的模板，并且注入DataSource数据源属性，(也可以自己创建JdbcTemplate)
>
> 4、定义好Service层调用DAO层的类，每一个Service层的方法都算是一个事务
>
> 5、在Service层对需要用到的事务的方法注解@Transactional注解，可以在里面传递事务的管理模式传播行为等等，可以在类上注解@Transactional注解，这表示对整个类中的所有的方法都是用Spring事务管理
>
> 6、在配置文件中配置事务注解驱动，会自动扫描@Transaction注解的类或者方法
>
> <tx:annotation-driven transaction-manager="AccountTransactionManager"/>
>
> 当调用Service层中的事务方法的时候就是自动进行事务管理

在使用XMl配置和注解方式两种配置中，使用最多的还是通过Xml配置为多数，使用注解配置太松散，而使用xml配置比较集中，方便管理



### 37、AOP小结

#### 	AOP 面向切面的编程

> 代理目标				类
> 连接点					类中的方法
>  切入点					需要增强的方法
> 通知						自定义增强的内容
> 切面						连接点+通知
> 织入						对方法进行增强的过程

#### 	AOP 实现的底层原理

> 代理模式
> 静态代理			真实存在的代理类
> 动态代理			运行时才生成的类
> spring AOP ：使用动态代理
> JDK动态代理：基于接口
> cglib动态代理：基于类

###  38、Spring小结

	> Spring事务主要分为三大块
	>
	> 1、IOC控制反转，用于创建对象
	>
	> 2、AOP动态代理，可以进行对象方法的代理，默认使用jdk，也可以设置成CgLib代理
	>
	> 3、Spring事务，主要有三种数据源，两种配置方式
	>
	> ​	数据源
	>
	> ​		—spring内置数据源
	>
	> ​		—DBCP数据源
	>
	> ​		—C3P0数据源
	>
	> ​	配置方式
	>
	> ​		—Xml配置方式
	>
	> ​		—注解配置方式		



## 2、Mybatis

### 	1、概述

> Mybatis，主要是对JDBC做了简易的封装，帮助用户实现sql的自动化映射，对查询的结果集进行自动化映射，缺点，sql语句还是需要用户手动编写

### 	2、工作流程

> 1、Mybatis有两个配置文件
>
> ​	Mybatis-config.xml，是Mybatis的全局配置文件，包含了配置信息，例如数据库的连接参数，插件
>
> ​	xxxMapper.xml，是映射配置文件，里面主要配置需要执行的sql语句，每个sql语句对应一个Statment，可以有多个Mapper.xml文件
>
> 2、首先通过SqlSessionFacotryBuilder来加载上述的两个配置文件，生成一个SqlSessionFactory工厂
>
> 3、通过SqlSessionFacoty工厂生成来获取SqlSession对象
>
> 4、Mybatis获取需要执行的Statement，进行sql的参数设置
>
> 5、sqlSession底层会通过Executor（执行器）来执行编译好的Statement来获取结果

### 	3、Mybatis使用

> 下面通过一个小 例子，来说明Mybatis的使用

导入一下的依赖包

> Asm.jar
>
> Cglib.jar
>
> Oracle8.jar
>
> Log4j.jar
>
> Mybatis.jar
>
> Javassist.jar
>
> Junit4.jar
>
> Slf4j-api
>
> Slf4j-nop

定义数据库的表结构

> 表名称 USEROR
>
> id					NUMBER
>
> username		VARCHAR2
>
> BIRTHDAY		DATE
>
> SEX				VARCHAR2
>
> ADDRESS	VARCHAR2

插入表数据

INSERT** **INTO** "user" **VALUES** ('1', '王五', **null**, '2', **null**);

**INSERT** **INTO** "user" **VALUES** ('10', '张三', **SYSDATE**, '1', '北京市');

**INSERT** **INTO** "user" **VALUES** ('16', '张小明', **null**, '1', '河南郑州');

**INSERT** **INTO** "user" **VALUES** ('22', '陈小明', **null**, '1', '河南郑州');

**INSERT** **INTO** "user" **VALUES** ('24', '张三丰', **null**, '1', '河南郑州');

**INSERT** **INTO** "user" **VALUES** ('25', '陈小明', **null**, '1', '河南郑州');

**INSERT** **INTO** "user" **VALUES** ('26', '王五', **null**, **null**, **null**);



定义表的POJO类

```
package com.pojo;

import java.util.Date;

public class User {
    private int id ;
    private String username;
    private String sex ;
    private Date birthday;
    private String address ;

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", sex='" + sex + '\'' +
                ", birthday=" + birthday +
                ", address='" + address + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
```

> 此类和表结构一一对应

定义User.xml

```
<?xml version="1.0" encoding="ISO-8859-1"?>

<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<!--namespace:命名空间，用于隔离sq1,还有一个很重要的作用，之后会涉及到-->
<mapper namespace="test">
<!--  此处主要定义SQL
        ID —— 表示对应的SqlID，在调用的时候用到
        parameterType —— 表示SQL中需要传递参数的类型
        resultType —— 表示查询结果所返回的数据类型，如果POJO类于表一一对应，Mybatis会自动封装成对象返回
        标签体 —— SQL语句 
-->
    <select id="queryUserById" parameterType="int" resultType="com.pojo.User">
        SELECT ID, USERNAME, BIRTHDAY, SEX, ADDRESS FROM USEROR WHERE ID = #{id}
    </select>
</mapper>
```

> 在这个XMl文件中，主要是需要配置SQL语句、传递参数类型、返回值封装，实现SQL不需要定义在程序中

定义sqlMapConfig.xml文件

```
<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE configuration
        PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
<!--  和Spring整合之后environment就将移除-->
    <environments default="development">
        <environment id="development">
<!--            使用JDBC事务管理-->
            <transactionManager type="JDBC"></transactionManager>
<!--            数据库连接池-->
            <dataSource type="POOLED">
                <property name="driver" value="oracle.jdbc.driver.OracleDriver"/>
                <property name="url" value="jdbc:oracle:thin:@192.168.63.128:1521:oracle"/>
                <property name="username" value="c##Web"/>
                <property name="password" value="admin123"/>
            </dataSource>
        </environment>
    </environments>

<!--    加载User.xml映射文件，里面主要定义SQL-->
    <mappers>
        <mapper resource="User.xml"></mapper>
    </mappers>
</configuration>
```

> 在这个配置文件中是Mybatis核心配置文件，里面主要定义数据库连接参数、以及加载之前定义的User.xml配置文件

测试类

```
package com.test;

import com.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.InputStream;

public class MybatisTest {

    @Test
    public void test() throws Exception{
        //1、创建SqlSessionFactoryBuilder对象
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        //2、加载sqlMapConfig.xml配置文件
        InputStream inputStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        //3、创建SqlSessionFactory对象
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(inputStream);
        //4、从SqlSessionFactory获取SqlSession对象
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //5、执行sql，第一个参数传递在User.xml配置文件设定sql的ID，第二个参数为sql中需要替换的参数，
        User user = sqlSession.selectOne("queryUserById",10); //此方法返回的是范型，类型在User.xml文件中配置
        //6、关闭资源
        sqlSession.close();
        
        System.out.println(user);
    }
}
```

> 在这个测试类中，Mybatis的流程
>
> 1、创建一个SqlSessionFactoryBuilder对象
>
> 2、通过Resources.getRecourceAsStream(sqlMapConfig.xml)来获取输入流
>
> 3、在通过SqlSessionFacotryBuilder对象的Builder方法传递刚刚获取的输入流，返回SqlSessionFactory对象
>
> 4、在通过SqlSessionFactory对象来获取sqlSession对象
>
> 5、得到的sqlsession对象就可以操作数据库，返回的是范型，也就是在User.xml定义返回类型
>
> 6、关闭资源



### 4、实现模糊查询，返回多条记录

> 当使用模糊查询或者查询全部数据的时候，会返回多条记录，在Mybatis中会自动将放回的数据封装成List集合

定义User.xml

```
<select id="queryUserNameLink" parameterType="com.pojo.User" resultType="com.pojo.User">
        SELECT id,username,birthday,sex,address FROM useror WHERE username LIKE #{username}
    </select>
```

> 这个配置中，输入的参数不一定是使用基本数据类型，也可以穿入一个Pojo对象，而#{属性名}这个会自动调用Pojo对象中的Set、get方法

测试类

```
@Test
public void test3() throws Exception{
    SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsReader("sqlMapConfig.xml")).openSession();
    
    User user = new User();
    //设置需要查询UserName
    user.setUsername("%%");
    //进行模糊查询，框架自动将记录封装成List集合
    List<Object> list = sqlSession.selectList("queryUserNameLink",user);
    
    Iterator<Object> iterator = list.iterator();
    while(iterator.hasNext()){
        System.out.println(iterator.next());
    }
}
```

> 在这个测试类中，只要将一个POJO对象的username属性设置成需要查询的内容，属性名称要与User.xml配置文件中的#{}一样，而且需要有set、get方法，查询到的结果会通过List集合参数返回



### 5、使用Mybatis插入一行数据

> 实现Mybatis插入数据

定义User.xml

```
<!--    增加语句-->
    <insert id="insertUser" parameterType="com.pojo.User" >
        INSERT INTO useror (id,username,birthday,sex,address) VALUES (IDADD.nextval,#{username},#{birthday},#{sex},#{address})
    </insert>
```

> 在这这段配置文件中，传入一个Pojo类，Mybatis会自动通过Set、get方法实现参数的替换

测试类

```
@Test
public void test2() throws Exception{
    SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
    SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(Resources.getResourceAsReader("sqlMapConfig.xml"));
    SqlSession sqlSession = sqlSessionFactory.openSession();
    
    //定义数据
    User user = new User();
    user.setUsername("TonyTucker");
    user.setBirthday(new Date());
    user.setSex("1");
    user.setAddress("广东");
    
    //插入数据，返回的是更新的行数
    int resource = sqlSession.insert("insertUser",user);
    //提交数据
    sqlSession.commit();
}
```



### 6、返回主键ID

> 返回主键自增iD的作用就是，插入数据时因为ID是通过数据库的序列完成id的自增，并没有在传入的pojo对象中设置，返回主键ID就是将数据库序列自增的ID返回给传入的pojo对象的id属性

user.xml配置文件

```
<insert id="insertUserKsy" parameterType="com.pojo.User" >
    <!-- 实现主键ID返回
        selectKey 标签实现主键返回
        keyColumn 对应主键对应表的列名称
        keyProperty 对应pojo属性
        oder 设置在执行insert的sql语句执行之前先执行查询ID的sql，还是在执行insert的sql语句执行之后在执行插叙id的sql
        这里的oder设置成AFTER是先执行sql语句在执行查询ID语句，如果设置成Before,则是先执行selectKey标签内的sql，在执行insert的sql
        resultType 返回id的数据类型
    -->
    <selectKey keyColumn="id" keyProperty="id" order="AFTER" resultType="int">
    		<!-- 查询当前序列ID的sql语句-->
        select IDADD.currval from dual
    </selectKey>
    INSERT INTO useror (id,username,birthday,sex,address) VALUES (IDADD.nextval,#{username},#{birthday},#{sex},#{address})
</insert>
```

> 在这个条查询语句中多了一个selectKey标签，这个标签就是用作主键ID的返回，
>
> 在selectkey标签中有几个属性需要注意
>
> keyColumn -- 对应主键对应表的列名称
>
> keyProperty -- 对应pojo属性
>
> order --   设置先执行sql，再执行selectkey的sql，如果是after是先执行sql，再执行selectkey的sql，如果before则相反
>
> resultType -- 表示返回的id数据类型

测试类

```
@Test
public void test4() throws Exception{
    SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(Resources.getResourceAsReader("sqlMapConfig.xml"));
    SqlSession sqlSession = sqlSessionFactory.openSession();
    User user = new User();
    user.setUsername("Tom");
    user.setBirthday(new Date());
    user.setSex("2");
    user.setAddress("上海");

    //执行sql
    sqlSession.insert("insertUserKsy",user);

    //在这个user对象中并没有设置id，而是通过数据库的序列完成id的设置，返回主键的id就是使数据库序列自增的id返回给对象
    System.out.println(user.getId());
    sqlSession.commit();
}
```

> 在这个测试类，并没有给pojo对象设置ID参数，ID参数是通过数据库序列生成，在通过刚刚设置的selectKey标签，将数据库序列生成的id返回给传入的pojo对象的属性中

### 7、使用Mybatis设置数据的更新操作

> 使用Mybatis实现数据的更新

User.xml定义

```
<!-- 数据的更新 parameterType 表述输入的数据类型
     #{username} #{id} 表示将传进来的对象属性设置进去
-->
<update id="updateUserName" parameterType="com.pojo.User" >
    UPDATE useror SET username = #{username} WHERE id = #{id}
</update>
```

> 在这个配置文件中定义的update标签，其中parameterType属性表示输入的参数类型

测试类

```
@Test
public void test5() throws Exception{
    SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsReader("sqlMapConfig.xml")).openSession();
    //设置属性内容
    User user = new User();
    user.setId(25);
    user.setUsername("帕加尼");

		// 执行sql
    int res = sqlSession.update("updateUserName",user);
    sqlSession.commit();
    System.out.println(res);
}
```

> 在测试中，应为配置了传入的参数是pojo对象，所以需要创建pojo对象，并设置需要的相关参数

### 8、使用Mybatis数据的删除

> 使用Mybatis实现数据的删除操作

定义User.xml

```
<!-- 数据的删除 parameterType 表述输入的数据类型
     #{id} 表示将传进来的对象的ID设置进去
-->
<delete id="deleteUser" parameterType="com.pojo.User">
    DELETE FROM useror WHERE id = #{id}
</delete>
```

> 在这个配置文件中配置一个delete标签，其中parameterType表示需要传入的参数类型，这里设置的是传入一个pojo类，#{id}表示将传入的pojo类中的id属性内容

测试类

```
@Test
public void test6()throws Exception {
    SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsReader("sqlMapConfig.xml")).openSession();
    //设置参数内容，用于一会的User.xml配置文件中的#{id}
    User user = new User() ;
    user.setId(42);

		//执行sql
    int res = sqlSession.delete("deleteUser",user);
    sqlSession.commit();
    System.out.println(res);
}
```

> 测试类中执行sql中，需要传递一个pojo对象，因为在配置文件设置的是输入数据类型是一个pojo对象，所以在执行sql中需要传递一个pojo对象，这个pojo需要设置相应的参数，用于sql语句的参数替换

### 9、Mybatis中#于$的区别

传入的参数在SQL中显示为字符串

​     eg:select id,name,age from student where id =#{id},当前端把id值1，传入到后台的时候，就相当于 select id,name,age from student where id ='1'.



$传入的参数在SqL中直接显示为传入的值

​    eg:select id,name,age from student where id =${id},当前端把id值1，传入到后台的时候，就相当于 select id,name,age from student where id = 1.



### 10、使用Mybatis实现模糊查询

sql语句

```
<select id="queryUserName" parameterType="string" resultType="com.pojo.User">
    SELECT id,username,birthday,sex,address FROM useror WHERE username LIKE '%${value}%'
</select>
```



### 11、使用Mapper接口

> 再使用Mapper接口，主要的作用代替的原来的Dao层接口，使用Mapper接口可以不需要写接口的实现类
>
> 使用Mapper接口需要一下规范完成开发
>
> 1、Mapper.xml 文件中的namespace与mapper接口的类路径相同。
>
> ​	—也就是说在定义User.xml文件中的空间命名
>
> 2、Mapper 接口方法名和Mapper.xml中定义的每个statement的id相同、
>
> —也就是白哦说，在Mapper接口中要与sqlID保持一致
>
> 3、Mapper 接口方法的输入参数类型和mapper.xml 中定义的每个sql 的，parameterType的类型相同
>
> ​	—sql输入参数类型parameterType属性要与接口中方法中传入的参数保持一致
>
> 4、Mapper 接口方法的输出参数类型和mapper.xml 中定义的每个sql 的resultType的类型相同
>
> ​	—表示sql输出参数parameterType属性要与接口中方法返回参数一致

定义一个Mapper.xml

```
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd" >
<configuration>
    <environments default="Mybatis">
        <environment id="Mybatis">
            <transactionManager type="JDBC"></transactionManager>
            <dataSource type="POOLED">
                <property name="driver" value="oracle.jdbc.driver.OracleDriver"/>
                <property name="url" value="jdbc:oracle:thin:@192.168.63.128:1521:oracle"/>
                <property name="username" value="c##Web"/>
                <property name="password" value="admin123"/>
            </dataSource>
        </environment>
    </environments>
    <mappers>
        <mapper resource="mapper/UserMapper.xml"></mapper>
    </mappers>
</configuration>
```

> 在这个Mapper.xm配置文件中，和之前操作并没有什么不同

定义哥UserMapper接口

```
package com.dao;

import com.pojo.User;

import java.util.List;

public interface UserMapper {

		//通过Id查询用户
    public User queryById(int id) ;
		//通过名称进行模糊查询
    public List<User> queryByName(String username) ;
		//保存用户
    public void insertUser(User user) ;
}
```

> 这个接口中，方法名称，传递参数，返回值都要与UserMapper.xml配置文件中保持一致

定义Usermapper.xml文件

```
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<!-- 命名空间 需要传入定义好的Mapper接口的包.类名称-->
<mapper namespace="com.dao.UserMapper">

    <!-- 要Mapper接口中的方法名称，传递参数，返回值保持一致-->
    <select id="queryById" resultType="com.pojo.User" parameterType="int">
        SELECT id,username,birthday,sex,address FROM useror WHERE id = #{id}
    </select>
    <!-- 要Mapper接口中的方法名称，传递参数，返回值保持一致-->
    <select id="queryByName" resultType="com.pojo.User" parameterType="string">
        SELECT id,username,birthday,sex,address FROM useror WHERE username LIKE '%${value}%'
    </select>
    <!-- 要Mapper接口中的方法名称，传递参数，返回值保持一致-->
    <insert id="insertUser" parameterType="com.pojo.User">
        INSERT INTO useror (id,username,birthday,sex,address) VALUES (IDADD.nextval,#{username},#{birthday},#{sex},#{address})
    </insert>
</mapper>
```

> 在这个文件中需要注意的是，maper标签的namespace参数徐亚平指定到Mapper接口的包.类
>
> 在每个定义sql标签中，sqlid，输入参数类型，返回值类型，都要与定义的UserMapper接口一一对应

测试类

```
@Test
public void insertUser() throws Exception{
    SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(Resources.getResourceAsReader("mapper/Mapper.xml"));
    SqlSession sqlSession = sqlSessionFactory.openSession() ;
    //获取Mapper的动态代理对象
    UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

    User user = new User();
    user.setUsername("马克42");
    user.setBirthday(new Date());
    user.setSex("男");
    user.setAddress("重庆");

    //执行sql
    userMapper.insertUser(user);
    sqlSession.commit();
    sqlSession.close();
}
```

> 在这个测试类中，不再通过Sqlsession来执行调用配置文件中的sql，而是通过，取得一个Mapper的动态代理对象，然后调用这个对象中的方法来执行sql，(这个对象也就是自定义的UserMapper接口)，如果是更新操作需要进行事务的提交，否则数据不会保存，执行完陈之后记得释放资源



### 12、自定义别名

> 自定义别名的用处就是在配置sql语句时，返回值类型，或者传入的参数都要写完整的包.类名称，自定义别名就是通过一个名称代替这个包.类

定义Mapper.xml配置文件

```
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd" >
<configuration>
    <!-- 配置别名，这个别名必须放在environments 标签前面 否则会出错 -->
    <typeAliases>
        <typeAlias alias="user" type="com.pojo.User"/>
    </typeAliases>

    <environments default="Mybatis">
        <environment id="Mybatis">
            <transactionManager type="JDBC"></transactionManager>
            <dataSource type="POOLED">
                <property name="driver" value="oracle.jdbc.driver.OracleDriver"/>
                <property name="url" value="jdbc:oracle:thin:@192.168.63.128:1521:oracle"/>
                <property name="username" value="c##Web"/>
                <property name="password" value="admin123"/>
            </dataSource>
        </environment>
    </environments>

    <mappers>
        <mapper resource="mapper/UserMapper.xml"></mapper>
    </mappers>
</configuration>
```

> 在这个配置文件中，typeAliases标签就是设置类的别名，在通过typeAlias设置具体的别名，type类的完整名称，alias自定义的别名，
>
> 需要注意的是在配置类typeAliases这个标签需要放在environments标签前面，否组会出现异常

定义UserMapper.xml

``` 
<!-- 要Mapper接口中的方法名称，传递参数，返回值保持一致-->
<select id="queryByName" resultType="user" parameterType="string">
    SELECT id,username,birthday,sex,address FROM useror WHERE username LIKE '%${value}%'
</select>
```

> 在这段sql语句之中，返回参数就可以用别名代替

### 13、传递包装Pojo对象

> 之前可以传递单个pojo对象作为查询条件，但是如果遇到一对多的情况，在一个类的属性保存另外一个类的情况
>
> 例如如下情况，在一个QueryVo类中的属性保存User类的对象

定义QueryVo

```
package com.pojo;

public class QueryVo {
		//保存User对象
    private User user ;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
```

> 在这个类中，保存User对象

定义MapperUser.xml

```
<!-- 使用pojo包装类进行参数传递-->
<select id="queryUserByNameVo" parameterType="com.pojo.QueryVo" resultType="com.pojo.User" >
    SELECT id,username,birthday,sex,address FROM useror WHERE username LIKE '%${user.username}%'
</select>
```

> 在这个配置文件中，使用user.username的烦事去除QueryVo对象中的user对象中的username属性

定义UserMapper接口

```
package com.dao;

import com.pojo.QueryVo;
import com.pojo.User;

import java.util.List;

public interface UserMapper {
    // 与UserMapper.xml文件中的id、输入类型，返回类型保持一致
    public List<User> queryUserByNameVo(QueryVo queryVo);
}
```

> 在Mapper接口中创建与UserMapper.xml文件中的SQLId保持相同

测试类

```
@Test
public void queryUserByNameVo() throws Exception{
    SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
    SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(Resources.getResourceAsReader("mapper/Mapper.xml"));
    SqlSession sqlSession = sqlSessionFactory.openSession() ;
    //取得Mapper接口的动态代理对象
    UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
    
    //设置参数
    QueryVo queryVo = new QueryVo();
    User user = new User();
    user.setUsername("马");
    queryVo.setUser(user);
    
    //执行sql
    List<User> list = userMapper.queryUserByNameVo(queryVo);
    for (User user1 : list){
        System.out.println(user1);
    }
}
```

>  通过执行Mapper接口个中的定义的queryUserByNameVo方法，就可以执行SQL语句，并返回List集合



### 14、使用resultMap映射

> 使用resultMap的情况就是，当java映射类和数据库字段不匹配时，让resultMap作为中间桥梁，使数据库字段能映射到java属性中

定义OrderMapper.xml

```
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">

<!-- 命名空间 需要传入定义好的Mapper接口的包.类名称-->
<mapper namespace="com.dao.OrderMapper">

    <!-- 使用resultMapper
        id —— 表示resultMap的iD，type表示映射的java类
    -->
    <resultMap id="OrderResultMap" type="com.pojo.Order">
<!--        id表示主键，property表示java类的Id属性，column表示对应数据库列名称的-->
        <id property="id" column="ID"/>

<!--        result 表示普通属性 property表示java类的属性，column表示对应的数据库列名称-->
        <result property="userid" column="USER_ID"/>
        <result property="numberor" column="NUMBER"/>
        <result property="createTime" column="CREATETIME"/>
        <result property="note" column="NOTE" />
    </resultMap>

<!-- 要使用resultMap属性应用ResultMap的ID-->
    <select id="findOrder" resultMap="OrderResultMap">
        SELECT id,user_id,numberor,CREATEtime,note FROM orders
    </select>
</mapper>
```

> 在这个配置文件中，使用resultMap标签，设置一个resultMap，type指定映射的java类，
>
> 通过id标签，result标签完成映射
>
> 在sql查询标签中，resultMap设置成resultMap的ID
>
> 注意：在sql查询语句中，返回值不能写resultType而是用resultMap，只需要写映射到属性，如果属性和表字段相同则可以不用写

### 15、动态SQL

> 动态sql就是在执行的过程中，组成sql，比如查询条件，可以判断传入进来的对象属性是否存在，然后判断是否需要增加查询条件

 定义UserMapper.xml

```
<select id="findUserWhere" resultType="com.pojo.User" parameterType="com.pojo.User">
    SELECT id,username,birthday,sex,address FROM useror
    <!-- where标签，会在sql后面增加where标签-->
    <where>
        <!--判断sex是否存在内容，如果存在内容增加sql查询条件，如果没有则不添加-->
        <if test=" sex != null ">
            AND sex = #{sex}
        </if>
        <!--判断传进来的pojo对象是否存在username属性内容，如果存在则增加sql查询条件，如果不存在则不添加查询条件-->
        <if test="username != null" >
            AND username LIKE '%${username}%'
        </if>
    </where>
</select>
```

> 增加一个查询标签，通过增加一个where标签来增加where条件，然后通过if判断传进来的对象的属性是否存在内容，如果存在则增加查询条件，不存在则不增加查询条件

定义UserMapper接口

```
package com.dao;

import com.pojo.Order;
import com.pojo.QueryVo;
import com.pojo.User;

import java.util.List;

public interface UserMapper {
    //与配置文件中select标签id对应
    public List<User> findUserWhere(User user);

}
```

> 增加一个方法，与sql的ID对应

测试类

```
@Test
public void findUserWhere() throws Exception{
    SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsReader("mapper/Mapper.xml")).openSession();
		//取得UserMapper接口代理对象
		UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
	
		//设置参数
		User user = new User();
    user.setSex("1");
    user.setUsername("张");
		
		//执行sql
    List<User> users = userMapper.findUserWhere(user) ;
    for (User user1: users) {
        System.out.println(user1);
    }
}
```

> 实现sql之后，Mybatis会自动判断sex和username的属性内容是否存在，存在则增加查询条件，不存在则不增加

### 16、SQL片段

> 所谓SQL片段可以减少过长的字段名称的重复代码

定义UserMapper.xml

```
<select id="findUserWhere" resultType="com.pojo.User" parameterType="com.pojo.User">
		<!-- 引用sql片段-->
    SELECT <include refid="UserorColumn"/> FROM useror
    <!-- where标签，会在sql后面增加where标签-->
    <where>
        <!--判断sex是否存在内容，如果存在内容增加sql查询条件，如果没有则不添加-->
        <if test=" sex != null ">
            AND sex = #{sex}
        </if>
        <!--判断传进来的pojo对象是否存在username属性内容，如果存在则增加sql查询条件，如果不存在则不添加查询条件-->
        <if test="username != null" >
            AND username LIKE '%${username}%'
        </if>
    </where>
</select>

<!-- sql片段 用于代替sql，解决字段过长的问题-->
<sql id="UserorColumn">
    id,username,birthday,sex,address
</sql>
```

> 在这个配置文件中，通过定一个SQL标签来设置sql片段
>
> 然后再查询语句中通过<include refid="SQL片段ID">标签来引入SQL片段
>
> 这样的好处是可以减少过长的字段重复代码，类似别名的作用

### 17、通过foreach输出，生成动态SQL

> foreach的使用场景，例如需要查询1，10，24ID的用户，那么SQL语句就是 WHERE id IN（1，10，24）
>
> foreach就是通过迭代输出，生成动态sql，拼接进去

定义QueryVo对象

```
package com.pojo;

import java.util.List;

public class QueryVo {

    private List<Integer> ids ;

    private User user ;

    public List<Integer> getIds() {
        return ids;
    }

    public void setIds(List<Integer> ids) {
        this.ids = ids;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
```

> 在这个类中，定义了一个List集合，这个集合存放了需要查询到ID

定义UserMapper.xml

```
<!-- 在QueryVo对象中，有ID的list集合-->
<select id="queryByIds" parameterType="com.pojo.QueryVo" resultType="com.pojo.User">
    SELECT id,username,birthday,sex,address FROM useror
    <where>
        <!--
            foreach标签，迭代输出集合中的内容
            conllection —— 对应输入对象的List集合属性
            item —— 为每次迭代的内容取一个名称，要与标签体的#{}要保持一致
            open —— 在前面添加SQl片段
            close —— 在结尾处添加SQL片段
            Separatory —— 表示每个输出内容直接用什么符号分割
         -->
        <foreach collection="ids" item="item" open="id IN (" close=")" separator=",">
        <!-- 输出内容-->
            #{item}
        </foreach>
    </where>
</select>
```

> 在这个映射文件中，通过Foreach迭代输出QueryVo对象中的ids的集合属性，然后拼接到sql语句中

赌博个图UserMapper接口

```
package com.dao;

import com.pojo.Order;
import com.pojo.QueryVo;
import com.pojo.User;

import java.util.List;

public interface UserMapper {

    public List<User> queryByIds(QueryVo vo);
}
```

> 在UserMapper之中定一个和映射文件中SQL到ID相同的方法

测试类

```
@Test
public void queryByIds() throws IOException{
    SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsReader("mapper/Mapper.xml")).openSession();
    UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
    
    //设置参数
    QueryVo queryVo = new QueryVo() ;
    List<Integer> ids = new ArrayList<>();
    ids.add(1);
    ids.add(10);
    ids.add(24);
    queryVo.setIds(ids);
    queryVo.setIds(ids);
    
    //执行sql
    List<User> list = userMapper.queryByIds(queryVo);
    for (User user : list){
        System.out.println(user);
    }
}
```

> 创建List集合，并传入参数，在保存到QueryVo对象中，在调用userMapper接口中定义好的queryByIds方法，返回List集合对象

### 18、Mybatis一对一数据表查询

> 在使用Mybatis查询一对一关系表的时候需要注意返回的类，应为一对一要查询两张表，有两种方式完成

#### 		第一种方式

> 通过继承两张数据的映射类的一个
>
> 两张数据表，一张是用户表，一张是订单表，一个用户有多个订单，一个订单只能对应一个用户
>
> 从订单表开始查就是一对一关系

定义OrderMapper.xml

```
<select id="queryOrderUser" resultType="com.pojo.OrderUser">
		<!-- 应为Order类中的属性名称为userid，所以查询语句设置别名为userid就可以完成映射-->
    SELECT o.ID,o.USER_ID userid,o.CREATETIME,o.NOTE,u.USERNAME,u.ADDRESS FROM useror u ,ORDERS o
</select>
```

> 在这个映射文件中，应为需要查询两张表的数据，所以一个Order类只有一个user_id的属性，剩下的address、username，都无法映射到Order类中
>
> 解决方法局势创建一个类，继承Order类，这样就会有order类中的属性，在添加两个属性address和username
>
> 在返回值类型中直接返回OrderUser类，这样就能完成数据表字段映射

定义OrderUser类

```
package com.pojo;

public class OrderUser  extends Order{
    private String username ;
    private String address ;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "OrderUser{" +
                "id='" + super.getId()+ '\'' +
                "user_id='" + super.getUserid()+ '\'' +
                ", address='" + address + '\'' +
                "，username='" + username + '\'' +
                "，createTime='" + super.getCreateTime() + '\'' +
                "，note='" + super.getNote() + '\'' +
                '}';
    }

}
```

> 在这个类中添加了两个字段的映射属性，分别是username和address，这样Mybatis在就会将两个字段属性映射到这个子类中

定影OrderMapper接口

```
package com.dao;

import com.pojo.Order;
import com.pojo.OrderUser;

import java.util.List;

public interface OrderMapper {
		//与映射文件的SQLid相匹配
    public List<OrderUser> queryOrderUser();

}
```

测试类

```
@Test
public void queryOrderUser() throws  Exception{
    SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsReader("mapper/Mapper.xml")).openSession();
    OrderMapper orderMapper = sqlSession.getMapper(OrderMapper.class);
    
    //执行sql
    List<OrderUser> orderUsers = orderMapper.queryOrderUser();
    for (OrderUser ou:
         orderUsers) {
        System.out.println(ou);
    }
}
```



#### 第二种方式

> 第二种方式，是将User对象存放在Order对象之中，Mybatis自动将查询的结果封装User再存放在对象之中

OrderMapper.xml

```
<!-- 定义resourMap 要与查询字段和属性名称一一对应-->
<resultMap id="OrderUserResultMap" type="com.pojo.Order">
    <id property="id" column="id" />
    <result property="userid" column="userid" />
    <result property="numberor" column="numberor" />
    <result property="createTime" column="createTime" />
    
    
    <!-- 将查询结果封装在Order对象中的User属性
        property指定Order对象中的User属性名，javaType属性类型
    -->
    <association property="user" javaType="com.pojo.User">
        <!-- 查询结果字段名映射到User对象中属性名，需要一一对应每个字段都必须要写，Mybatis不会自动封装-->
        <id property="id" column="userid"/>
        <result property="username" column="username"/>
        <result property="sex" column="sex" />
        <result property="address" column="address" />
        <result property="birthday" column="birthday"/>
    </association>
</resultMap>


<select id="queryOrder" resultMap="OrderUserResultMap">
    SELECT o.ID,o.USER_ID userid,o.NUMBEROR,o.CREATETIME,o.NOTE,u.USERNAME,u.ADDRESS,u.sex,u.birthday FROM useror u ,ORDERS o WHERE u.ID = o.USER_ID
</select>
```

> 在这个配置文件中需要定一个resultMap标签，将查询结果映射到Order类中User属性
>
> 需要注意的是，查询结果的每一个字段都必须要要映射，就算属性名称与查询字段名称相同，也要写result
>
> 否则查询结果不会封装到属性里
>
> 查询的结果会自动封装成，resultMap标签中的type类型，如果是多条数据则返回LIst集合

定义OrderMaper接口

```
package com.dao;

import com.pojo.Order;
import com.pojo.OrderUser;

import java.util.List;

public interface OrderMapper {
		//与OrderMapper.xml文件中sql的ID保持一致
    public List<Order> queryOrder() ;
}
```

测试类

```
@Test
public void queryOrder() throws IOException{
    SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsReader("mapper/Mapper.xml")).openSession();
    OrderMapper orderMapper = sqlSession.getMapper(OrderMapper.class);
    //执行sql，返回list集合
    List<Order> orders = orderMapper.queryOrder();
    for (Order order: orders
         ) {
        System.out.println(order);
    }
}
```



### 19、Mybatis一对多数据表查询

> 在实现一对多数据表查询，就是通过将一的对象存放一个List集合保存多的对象
>
> 例如，一个用户会存在多个订单，那么就只需要在用户对象中使用一个List集合保存订单对象

例子

定义User对象

```
package com.pojo;

import java.util.Date;
import java.util.List;

public class User {
    private int id ;
    private String username ;
    private Date birthday ;
    private String sex ;
    private String address ;
		
		//保存Order对象
    private List<Order> orders ;
	
	// Set、get略
}
```

> 通过一个LIst集合保存Order对象集合

定义UserMapper.xml

```
<!--配置resultMap映射-->
<resultMap id="queryOrderUserMap" type="com.pojo.User">
		<!-- 配置User对象中的属性映射-->
    <id property="id" column="id" />
    <result property="username" column="username" />
    <result property="birthday" column="birthday" />
    <result property="sex" column="sex" />
    <result property="address" column="address" />
    
    <!--配置User对象中List的映射
    	property —— 表示User对象中的属性名称
    	ofType —— 表示List集合对象的范型类型
    -->
    <collection property="orders" ofType="com.pojo.Order" >
    		<!-- property —— 范型中的属性名称
    				column —— 查询结果的表字段
    		-->
        <id property="id" column="oid" />
        <result property="numberor" column="numberor" />
        <result property="createTime" column="CREATETIME" />
    </collection>
</resultMap>

<!-- 返回ResultMap类型-->
<select id="queryOrder" resultMap="queryOrderUserMap">
    SELECT u.ID,u.USERNAME,u.birthday,u.SEX,u.ADDRESS,o.ID oid,o.NUMBEROR,o.CREATETIME,o.NUMBEROR FROM ORDERS o , USEROR u
        WHERE  u.ID = o.USER_ID(+)
</select>
```

> 在这个映射文件中，核心就是Collection标签，这个标签会自动将查询结果封装到Order对象到User的List集合中，前提是需要将查询结果的字段与属性名称设置好映射

定义UserMapper接口

```
package com.dao;

import com.pojo.Order;
import com.pojo.QueryVo;
import com.pojo.User;

import java.util.List;

public interface UserMapper {
		// 与映射文件中的SQL的ID一一对应
    public List<User> queryOrder();
}
```

测试类

```
@Test
public void queryOrder() throws Exception{
    SqlSession sqlSession = new SqlSessionFactoryBuilder().build(Resources.getResourceAsReader("mapper/Mapper.xml")).openSession();
    UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

		//执行sql
    List<User> users = userMapper.queryOrder();
    for (User user : users){
        System.out.println(user);
    }
}
```

### 20、Spring与Mybatis整合

> 在整合之前需要以下的依赖包
>
> Spring的几个核心包（包括AOP）
>
> aopalliance1.0联盟
>
> Aspectj-weaver
>
> Mybatis的核心包
>
> Spring-Mybatis整合包
>
> DBCP数据源
>
> commons-pool
>
> commons-logging
>
> Spring-jdbc
>
> spring-tx
>
> log4j
>
> 数据库驱动包
>
> 这些驱动包都需要注意版本一致，Spring的jar包都要注意版本

#### 第一种方式

> Spring整合Mybatis有两种写法，一种是传统的DAO开发，需要创建一个接口，由用户去写实现类

创建一个POJO对象

```》 
package com.pojo;

import java.util.Date;

public class User {
    private int id ;
    private String username ;
    private Date birthday ;
    private String sex ;
    private String address ;

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", birthday=" + birthday +
                ", sex='" + sex + '\'' +
                ", address='" + address + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
```

> 这是一个与数据表结构一样的对象，用户数据的传输

定义sqlMapConfig.xml文件

```
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration
        PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
    <!-- 设置别名-->
    <typeAliases>
        <!-- 扫描这个包下的所有类，别名就是类名称-->
        <package name="com.pojo"/>
    </typeAliases>

    <!--导入映射文件-->
    <mappers>
        <mapper resource="mapper/UserMapper" />
    </mappers>
</configuration>
```

> 这个文件是Mybatis的核心配置文件，这个文件主要需要配置：包别名、以及映射文件

定义UserMapper.xml

```
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">

<!--此程序还未使用到动态生成实现类，所以这里暂时写啥都无所谓-->
<mapper namespace="test">

		<!--通过用户ID查询-->
    <select id="queryById" parameterType="int" resultType="com.pojo.User">
        SELECT ID, USERNAME, BIRTHDAY, SEX, ADDRESS FROM USEROR
        <where>
            <if test="value != null">
                AND id = #{value}
            </if>
        </where>
    </select>

		<!--通过用户名进行模糊查询-->
    <select id="queryByUserName" parameterType="string" resultType="com.pojo.User">
        SELECT id,USERNAME,BIRTHDAY,SEX,ADDRESS FROM useror
        <where>
            <if test="value != null">
                AND username LIKE '%${value}%'
            </if>
        </where>
    </select>

		<!--保存用户-->
    <insert id="saveUser" parameterType="com.pojo.User" >
    <!--返回主键-->
        <selectKey keyProperty="id" keyColumn="id" order="AFTER" resultType="int">
            SELECT IDADD.currval FROM dual
        </selectKey>
        INSERT INTO useror (id,username,birthday,sex,address) VALUES (IDADD.nextval,#{username},#{birthday},#{sex},#{address})
    </insert>

</mapper>
```

> 这个配置文件主要作用是，定义sql语句设置返回值，传入参数类型

定义IuserDAO接口

```
package com.dao;

import com.pojo.User;

import java.util.List;

public interface IUserDao  {
    public User queryById(int id);

    public List<User> queryByUserName(String username);

    public void saveUser(User user) ;

}
```

> 这个接口中的方法要与UserMapper.xml文件配置的SQL的ID相同，返回参数，传入参数都要一一对应，如果返回多条结果，则返回值设置为LIst集合

定义UserDaoImpl类

```
package com.dao.imp;

import com.dao.IUserDao;
import com.pojo.User;
import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import java.util.List;

public class UserDaoImpl extends SqlSessionDaoSupport implements IUserDao {
    @Override
    public User queryById(int id) {
        SqlSession sqlSession =  super.getSqlSession();
        User user = sqlSession.selectOne("queryById",id);
        return user ;
    }

    @Override
    public List<User> queryByUserName(String username) {
        SqlSession sqlSession = super.getSqlSession();
        List<User> list = sqlSession.selectList("queryByUserName",username);
        return list ;
    }

    @Override
    public void saveUser(User user) {
        super.getSqlSession().insert("saveUser",user);
    }
}
```

> 定一个类，这个类需要实现IUserDao接口中方法，通过还需要继承SqlSessionSupport这个类
>
> 在这个SqlSessionSupport类中有一个getSqlSession()的方法，这个方法就可以选择去执行那条Sql，和传入参数，此外这个类还需要注入一个sqlSessionFactory的属性，这个可以通过Spring创建和注入

创建ApplicationContext.xml

```
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:aop="http://www.springframework.org/schema/aop"
       xmlns:context="http://www.springframework.org/schema/context"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
       http://www.springframework.org/schema/beans/spring-beans.xsd
       http://www.springframework.org/schema/aop
       http://www.springframework.org/schema/aop/spring-aop.xsd
       http://www.springframework.org/schema/context
       http://www.springframework.org/schema/context/spring-context.xsd">

    <!-- 定义一个DBCP数据源，c3p0也可以-->
    <context:property-placeholder location="jdbc.properties"/>
        <bean id="dataSource" class="org.apache.commons.dbcp2.BasicDataSource                                                                               ">
        <property name="driverClassName" value="${jdbc.driverClass}"/>
        <property name="url" value="${jdbc.url}"/>
        <property name="username" value="${jdbc.username}"/>
        <property name="password" value="${jdbc.password}"/>
    </bean>

    <!-- 配置SqlSessionFactory -->
    <bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
        <!-- 配置mybatis核心配置文件 -->
        <property name="configLocation" value="classpath:sqlMapConfig.xml" />
        <!-- 注入数据源 -->
        <property name="dataSource" ref="dataSource" />
    </bean>

    <!--通过Spring创建IUserDao的实现类-->
    <bean id="userDao" class="com.dao.imp.UserDaoImpl">
        <!-- 应为此类继承类SqlSessionSupport所以需要注入一个SqlSessionFactory的工厂-->
        <property name="sqlSessionFactory" ref="sqlSessionFactory"/>
    </bean>
</beans>
```

> 首先在这个文件中，需要配置数据源，然后配置一个Bean创建SqlSessionfacotry，但是需要注意的是创建的是SqlsessionFacotryBean对象而不是SqlsessionFacotry对象
>
> 这个x对需要注入数据源，里面有datasource属性，直接通过property标签注入即可
>
> 还有一个configLocation属性，这个属性是配置SqlMapConfig.xml文件的路径(也就是Mybatis的配置文件)
>
> 此外还需要配置一个Bean，创建的对象为UserDaoImpl，由于这个类继承SqlSessionSupport，所欲需要注入SqlSessionFacotry这个属性才能取得SqlSession连接

测试类

```
package com;

import com.dao.IUserDao;
import com.pojo.User;
import org.junit.Before;
import org.junit.Test;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Date;
import java.util.List;

public class test1 {

    private IUserDao iUserDao ;

    @Before
    public void init(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
        this.iUserDao = applicationContext.getBean(IUserDao.class);
    }
    @Test
    public void saveUser(){
        User user = new User() ;
        user.setUsername("Assassins");
        user.setSex("男");
        user.setBirthday(new Date());
        user.setAddress("Uplay");
        this.iUserDao.saveUser(user);
        System.out.println(user);
    }
}
```

> 测试类中只测试了保存的方法，就是通过获取UserDaoImpl的类，调用需要的方法就可以实现数据CRUD

#### 第二种方式

> 第二种方式就会方便很多，通过Mybatis生成动态代理对象

Pojo对象略



定义UserMapperDao.xml文件

```
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd" >

<!-- 配置对应接口的路径-->
<mapper namespace="com.mapperdao.UserMapperDao">
    <!-- 查询语句-->
    <select id="queryByName" resultType="com.pojo.User" parameterType="string" >
        SELECT id,username,birthday,sex,address FROM useror
        <where>
            <if test="value != null">
                AND username LIKE '%${value}%'
            </if>
        </where>
    </select>
</mapper>
```

> 定义UserMapperDao.xml配置文件，此配置主要作用是些SQL语句

定义UserMapperDao接口

```
package com.mapperdao;

import com.pojo.User;

import java.util.List;

public interface UserMapperDao {
    public List<User> queryByName(String username);
}
```

> 定义这个接口，方法名称需要和配置文件相同，而且配置文件和接口都需要放在同一个目录下

定义applicationContext.xml

```
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd">
    <context:property-placeholder location="jdbc.properties"/>
    <bean id="dataSource" class="org.apache.commons.dbcp2.BasicDataSource" >
        <property name="driverClassName" value="${jdbc.driverClass}"/>
        <property name="url" value="${jdbc.url}"/>
        <property name="username" value="${jdbc.username}"/>
        <property name="password" value="${jdbc.password}"/>
    </bean>

     <!-- 创建SqlSessionFactory-->
    <bean id="SqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
        <!-- 传入Mybatis配置文件-->
        <property name="configLocation" value="SqlMapConfig.xml" />
        <!-- 传入数据源-->
        <property name="dataSource" ref="dataSource"/>
    </bean>

		<!-- 配置Mapper动态代理对象-->
    <bean class="org.mybatis.spring.mapper.MapperScannerConfigurer">
    		<!--配置自动扫描，扫描定义的Mapper接口-->
        <property name="basePackage" value="com.mapperdao"/>
    </bean>
    
</beans>
```

> 在这个配置文件中，最主要的配置Mapper动态代理对象，MapperScannerConfigurer这个类中会有一个basePackage属性，这个属性指定的定义UserMapper接口所在的包，对应的映射Xml文件也需要同时存在

测试类

```
import com.mapperdao.UserMapperDao;
import com.pojo.User;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class test_02 {

    private ApplicationContext applicationContext ;


    @Before
    public void init(){
        this.applicationContext = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
    }

    @Test
    public void test(){
        UserMapperDao userMapperDao = this.applicationContext.getBean(UserMapperDao.class);
        List<User> list = userMapperDao.queryByName("张");
        for (User user : list){
            System.out.println(user);
        }
    }
}
```

> 测试类只需要获取UserMapper接口的动态代理对象，然后调用接口中的方法就可以调用UserXml配置文件中的SQL语句

### 21、Mybatis逆向工程

> 所谓逆向工程就是自动生成Pojo类、Mapper接口、和Mapper的xml文件，
>
> 它会根据数据库结构自动生成相应类、接口、配置文件，属于一个方便的工具

加入依赖包

```
<dependency>
  <groupId>org.mybatis.generator</groupId>
  <artifactId>mybatis-generator-core</artifactId>
  <version>1.3.7</version>
</dependency>
```

> 逆向工程需要添加一个依赖包mybatis-generator-core

定义generatorConfig.xml文件

```
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE generatorConfiguration PUBLIC "-//mybatis.org//DTD MyBatis Generator Configuration 1.0//EN" "http://mybatis.org/dtd/mybatis-generator-config_1_0.dtd">

<generatorConfiguration>
    <context id="DB2Tables" targetRuntime="MyBatis3">
        <commentGenerator>
            <!-- 是否去除自动生成的注释 -->
            <property name="suppressAllComments" value="true"/>
        </commentGenerator>
        <!-- Mysql数据库连接的信息：驱动类、连接地址、用户名、密码 -->
        <jdbcConnection driverClass="oracle.jdbc.driver.OracleDriver"
                connectionURL="jdbc:oracle:thin:@192.168.63.128:1521:oracle"
                userId="c##Web"
                password="admin123">
        </jdbcConnection>


        <!-- 默认为false，把JDBC DECIMAL 和NUMERIC类型解析为Integer，为true时
        把JDBC DECIMAL 和NUMERIC类型解析为java.math.BigDecimal -->
        <javaTypeResolver >
            <property name="forceBigDecimals" value="false" />
        </javaTypeResolver>

        <!-- targetProject：生成POJO类的位置 -->
        <!-- targetProject：可以写绝对路径-->
        <javaModelGenerator targetPackage="com.pojo" targetProject="/Users/tonytucker/IdeaProjects/springMybatis_04/src/main/webapp/WEB-INF/java">
            <!-- enableSubPackages:是否让schema作为包的后缀 -->
            <property name="enableSubPackages" value="false" />
            <!-- 从数据库返回的值被清理前后的空格 -->
            <property name="trimStrings" value="true" />
        </javaModelGenerator>

        <!-- targetProject：mapper映射文件生成的位置 -->
        <!-- targetProject：可以写绝对路径-->
        <sqlMapGenerator targetPackage="com.dao.mapper"  targetProject="/Users/tonytucker/IdeaProjects/springMybatis_04/src/main/webapp/WEB-INF/java">
            <!-- enableSubPackages:是否让schema作为包的后缀 -->
            <property name="enableSubPackages" value="false" />
        </sqlMapGenerator>

        <!-- targetProject：mapper接口生成的的位置 -->
        <!-- targetProject：可以写绝对路径-->
        <javaClientGenerator type="XMLMAPPER" targetPackage="com.dao.mapper"  targetProject="/Users/tonytucker/IdeaProjects/springMybatis_04/src/main/webapp/WEB-INF/java">
            <!-- enableSubPackages:是否让schema作为包的后缀 -->
            <property name="enableSubPackages" value="false" />
        </javaClientGenerator>

        <!-- 指定数据表 -->
        <table schema="" tableName="useror"></table>
        <table schema="" tableName="orders"></table>

        <!-- 有些表的字段需要指定java类型
        <table schema="DB2ADMIN" tableName="ALLTYPES" domainObjectName="Customer" >
          <property name="useActualColumnNames" value="true"/>
          <generatedKey column="ID" sqlStatement="DB2" identity="true" />
          <columnOverride column="DATE_FIELD" property="startDate" />
          <ignoreColumn column="FRED" />
          <columnOverride column="LONG_VARCHAR_FIELD" jdbcType="VARCHAR" />
        </table> -->

    </context>
</generatorConfiguration>
```

>  这这个逆向工程主要配置文件
>
> 里面包括数据库连接、输出pojo类路径、mapper接口路径、映射Xml路径、指定的数据表

定义主方法

```
import java.io.File;
import java.util.*;

import org.mybatis.generator.api.MyBatisGenerator;
import org.mybatis.generator.config.Configuration;
import org.mybatis.generator.config.xml.ConfigurationParser;
import org.mybatis.generator.internal.DefaultShellCallback;

public class GeneratorSqlmap {

    public void generator() throws Exception {
        List<String> warnings = new ArrayList<String>();
        boolean overwrite = true;
        // 指定配置文件
        File configFile = new File("/Users/tonytucker/IdeaProjects/springMybatis_04/src/main/webapp/WEB-INF/config/maven/generatorConfig.xml"); // generatorConfig.xml文件的绝对路径
        ConfigurationParser cp = new ConfigurationParser(warnings);
        Configuration config = cp.parseConfiguration(configFile);
        DefaultShellCallback callback = new DefaultShellCallback(overwrite);
        MyBatisGenerator myBatisGenerator = new MyBatisGenerator(config, callback, warnings);
        myBatisGenerator.generate(null);
    }

    // 执行main方法以生成代码
    public static void main(String[] args) {
        try {
            GeneratorSqlmap generatorSqlmap = new GeneratorSqlmap();
            generatorSqlmap.generator();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

> 这是官方给出的方法，在网上拷贝下来运行就可以了
>
> 需要注意的是需要传入generatorConfig.xml文件路径，可以穿绝对路径
>
> 最后运行即可，可以时间会有点久







## 3、SpringMvc

### 	1、工作原理

> 此框架大致工作原理
>
> 1、客户端发送过来的请求都又一个Servlet（DispatcherServlet）来接收
>
> 2、当这个控制器接收到请求，调用HandlerMapping处理器映射处理器
>
> 3、**HandlerMapping**找到找到具体的处理器以及拦截器一同返回给DispatcherService
>
> 4、DispatcherService在调用HandlerAdpter处理器适配器
>
> 5、HandlerAdpter再去调用具体处理器（这里也就是业务逻辑，调用Service）
>
> 6、处理器完成之后返回处理结果给HandlerAdpter
>
> 7、HandlerAdpter在将处理结果封装成ModeAndView返回给DispatcherService控制器
>
> 8、DispatcherService再将接收到modelAndView传给viewReslover视图解析器
>
> 9、ViewReslover解析后返回具体到view
>
> 10、DIspatcherService在根据具体到view进行渲染试图
>
> 11、最后将渲染好的视图返回给用户



> 在以上中各个组件的说明
>
> DispatcherServlet：作为前端控制器，整个流程控制的中心，控制其它组件执行，统一调度，降低组件之间的耦合性，提高每个组件的扩展性。
>
> HandlerMapping：通过扩展处理器映射器实现不同的映射方式，例如：配置文件方式，实现接口方式，注解方式等。 
>
> HandlAdapter：通过扩展处理器适配器，支持更多类型的处理器。
>
> ViewResolver：通过扩展视图解析器，支持更多类型的视图解析，例如：jsp、freemarker、pdf、excel等。

下面通过一个例子来解释SpringMvc

> 使用SpringMvc所使用的开发包
>
> Spring-Context
>
> Spring-tx
>
> Spring-web
>
> Spring-webMvc
>
> JSTL1.2
>
> JSTL-imp (jstl-api,servlet-api)

注意：当使用Jstl标签库的时候需要导入JSTL的impl，不然运行JSP页面会出现错误

配置Web.xml

```
<!-- 用idea自动生成的web.xml中，
在配置servlet后，
如果发现web-app报错了，代码本身并没有出现什么问题，就是说明这是由于生成的web.xml对servlet标签不支持所致
加入一下代码
-->
<web-app xmlns="http://java.sun.com/xml/ns/j2ee"
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
          xsi:schemaLocation="http://java.sun.com/xml/ns/j2ee http://java.sun.com/xml/ns/j2ee/web-app_2_4.xsd"
          version="2.4">
  <!-- 是servlet的描述性说明文字，可以不需要写-->
  <display-name id="springMvc-config"></display-name>
 <!-- 次标签设置为首页面，容器会依次从上往下查找首页是否存在，如果不存在返回404错误或者显示根目录-->
  <welcome-file-list>
    <welcome-file>index.html</welcome-file>
    <welcome-file>index.htm</welcome-file>
    <welcome-file>index.jsp</welcome-file>
    <welcome-file>default.html</welcome-file>
    <welcome-file>default.htm</welcome-file>
    <welcome-file>default.jsp</welcome-file>
  </welcome-file-list>

  <!-- 配置SpringMvc前端控制器的Servlet-->
  <servlet>
    <servlet-name>springmvc</servlet-name>
    <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
    <!-- 引入SrpingMvc的Xml文件配置-->
    <init-param>
      <param-name>contextConfigLocation</param-name>
      <param-value>classpath:config/SpringMvc.xml</param-value>
    </init-param>
  </servlet>
  <servlet-mapping>
    <servlet-name>springmvc</servlet-name>
    <url-pattern>*.action</url-pattern>
  </servlet-mapping>
</web-app>
```

> 在这个配置中，主要是配置好DispatcherServlet这个Servlet，这个类是SpringMvc的控制器，主要接收所有的请求，在判断调用相应的Servlet
>
> PS注意：在配置servlet后，如果发现web-app报错了，代码本身并没有出现什么问题，就是说明这是由于生成的web.xml对servlet标签不支持所致，需要添加上面的代码

在资源文件中创建以配置SpringMvc.xml配置文件

```a
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd">
		<!-- 配置controller的扫描包-->
    <context:component-scan base-package="com.igeek.springmvc.controller"/>
    <!-- 配置SpringMvc注解驱动
        需要注意导入的约束是xmlns:mvc
    -->
    <mvc:annotation-driven />
    
</beans>
```

> 在配置文件中，只需要配置好扫描包的路径，和Bens的注解一样，Spring会自动扫描@Contorller注解的类。

定义一个vo类



定义一个controller的

```
package com.igeek.springmvc.controller;

import com.igeek.springmvc.vo.Item;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller //注解为控制器，把这个Controller交给Spring管理
public class ItemController {

    //注解为RequestMapping主要使用写用户请求的url，被注解的方法需要返回ModelAndView
    @RequestMapping("/itemList.action") //其中的.action可以不加，应为在Web.xml配置文件中已经配置类.action
    public ModelAndView queryItemList(){
        List<Item> list = new ArrayList<Item>();
        Item item = new Item();
        item.setId(1);
        item.setName("Rezer 1");
        item.setPrice(111D);
        item.setCreateTime(new Date());
        item.setDetail("雷蛇 1");
        list.add(item);

        item = new Item();
        item.setId(2);
        item.setName("Rezer 2");
        item.setPrice(222D);
        item.setCreateTime(new Date());
        item.setDetail("雷蛇 2");
        list.add(item);

        item = new Item();
        item.setId(3);
        item.setName("Rezer 3");
        item.setPrice(333D);
        item.setCreateTime(new Date());
        item.setDetail("雷蛇 3");
        list.add(item);

        //创建一个ModelAndView，用来存放数据和试图（也就是内置对象，以及JSP页面路径）
        ModelAndView modelAndView = new ModelAndView();
        //将数据设置到模型中，相当设置request的属性范围
        modelAndView.addObject("itmeList",list);
        //设置试图JSP，也就是跳转的JSP路径
        modelAndView.setViewName("/WEB-INF/jsp/ltemList.jsp");
        //将创建好的视图返回出去
        return modelAndView ;
    }
}

```

> 在这个控制器中，主要做以下几个步骤
>
> 1、为类注解@Controller，让这个类交由Spring管理
>
> 2、写一个方法并返回ModelAndView对象，并注解为@RequestMapping传递映射路径
>
> 3、操作Service层进行CRUD，具体的业务逻辑
>
> 4、创建一个ModelAndView对象，这个对象存放试图也就数据（JSP路径和request数据）
>
> 5、调用.addObject( )方法传递数据，和四个属性范围使用方法一样

创建一个VO对象

```
package com.igeek.springmvc.vo;

import java.util.Date;

public class Item {
    private int id ;
    private String name ;
    private Double price ;
    private Date createTime ;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    private String detail ;
}
```

> 这个映射对象由几个属性，id、name、price、createTime、detail

定义ItemListJsp（此页面用于查询数据）

```
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="sql" uri="http://java.sun.com/jsp/jstl/sql" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%--
  Created by IntelliJ IDEA.
  User: tonytucker
  Date: 2019/9/17
  Time: 9:48 上午
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8"%>

<html>
<head>
    <title>商品查询列表</title>
</head>
<body>
<form action="" method="post">
    <table width="100%" border="1">
        <tr>
            <td>商品ID <input type="text" name="${item.id}"></td>
            <td>商品名称 <input type="text" name="${itme.name}"></td>
            <td><input type="submit" value="查询" /> </td>
        </tr>
    </table>
    <table width="100%" border="">
        <tr>
            <td>商品ID</td>
            <td>商品名称</td>
            <td>商品价格</td>
            <td>创建时间</td>
            <td>商品描述</td>
        </tr>
        <!-- 通过JSTL的forEach标签迭代输出查询内容-->
        <c:forEach items="${itmeList}" var="item">
            <tr>
                <td>${item.id}</td>
                <td>${item.name}</td>
                <td>${item.price}</td>
                <td><fmt:formatDate value="${item.createTime}" pattern="YYYY-MM-DD HH:mm:ss" /></td>
                <td>${item.detail}</td>
            </tr>
        </c:forEach>
    </table>
</form>
</body>
</html>
```

> 在这个JSP页面中，最主要的就是通过forEache迭代输出从ItemController传递出来的List集合

然后就将项目部署到Tomcat之中，在根目录路径下访问/itemList.action,这个主要看控制器方法的@RequestMapping注解传递的url路径

### 2、SpringMvc三大组件

> - **处理器映射器：**用户请求路径到Controller方法的映射
> - **处理器适配器**：根据handler(controlelr类）的开发方式（注解开发/其他开发） 方式的不同区寻找不同的处理器适配器
> - **视图解析器**：根据handler返回的view地址文件类型（jsp/pdf….）去寻找相应的视图解析器来进行解析

### 3、MVC视图解析器

> 配置视图解析器，配置完成之后在编写控制器返回页面时候就可以不用写路径，直接写sp文件名

配置文件

```
<!-- 配置视图解析器，配置完成之后在编写控制器返回页面时候就可以不用写路径，直接先jsp文件名-->
<bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
    <!-- 配置页面的前缀，也就是父路径-->
    <property name="prefix" value="/jsp/"/>
    <!-- 配置页面的后缀，也就是后缀名-->
    <property name="suffix" value=".jsp"/>
</bean>
```

> 在这个配置文件中，使用Bean创建一个InternalResourceViewResolver的视图解析器，然后注入两个参数一个是prefix（页面前缀），一个是suffix（页面后缀）

定义controller控制器

```
@Controller
public class CommodityController {
    @RequestMapping("/jsp/LstCommodity.action")
    public ModelAndView ListCommodity(){
        ModelAndView modelAndView = new ModelAndView();
        List<Commodity> list = new ArrayList<>();
        list.add(new Commodity(1,"Asus",new Date(),9999D));
        list.add(new Commodity(2,"Rezer",new Date(),999D));
        list.add(new Commodity(3,"Apple",new Date(),99D));
        list.add(new Commodity(4,"Hp",new Date(),9D));
        
        modelAndView.addObject("ListCommodity",list);
        modelAndView.setViewName("ListCommodity"); // 可直接编写文件名称，应为配置了视图解析器
        return modelAndView ;
    }
}
```

> 在编写Controller控制器，设置视图路径就可以直接写文件名，路径和后缀都通过配置文件来定义

### 4、SpringMvc整合Mybatis

> 一下例子是一个基本的环境搭配



整合思路

Dao层:

1. SqlMapOonfigxml,空文件即可，但是需要文件头。

2. ```
   <?xml version="1.0" encoding="UTF-8"?>
   <!DOCTYPE configuration
           PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
           "http://mybatis.org/dtd/mybatis-3-config.dtd">
   <configuration>
       <!-- 配置Mapper的映射文件的扫描-->
       <mappers>
           <package name="com.mapper"/>
       </mappers>
   </configuration>
   ```

3. applicationOontext-dao.xml

   数据库连接池

   SqSessionFactory对象， 需要spring和mybatis整合包下的

   配置mapper文件扫描器

   ```
   <?xml version="1.0" encoding="UTF-8"?>
   <beans xmlns="http://www.springframework.org/schema/beans"
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
          xmlns:context="http://www.springframework.org/schema/context"
          xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd">
   
       <!-- 配置数据源-->
       <context:property-placeholder location="classpath:spring/jdbc.properties"/>
       <bean id="dataSource" class="org.apache.commons.dbcp2.BasicDataSource">
           <property name="driverClassName" value="${jdbc.driverClass}"/>
           <property name="url" value="${jdbc.url}"/>
           <property name="username" value="${jdbc.user}"/>
           <property name="password" value="${jdbc.password}"/>
       </bean>
   
       <!-- 创建SqlSessionFactory-->
       <bean id="SqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
           <property name="dataSource" ref="dataSource"/>
           <property name="configLocation" value="classpath:mybatis/sqlMapConfig.xml"/>
       </bean>
   
       <!-- 配置Mapper接口的扫描包
           会自动扫描定义的包下所有的Mapper接口
       -->
       <bean class="org.mybatis.spring.mapper.MapperScannerConfigurer">
           <property name="basePackage" value="com.mapper"/>
       </bean>
   </beans>
   ```

   

Service层:

1、applicationOontext-service.xml 包扫描器,扫描@service注解的类。

```
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd">

    <!-- 扫描注解@Service的类-->
    <context:component-scan base-package="com.service"/>

</beans>
```

2、applicationOntext-transxml 配置事务。

```
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:tx="http://www.springframework.org/schema/tx" xmlns:aop="http://www.springframework.org/schema/aop"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
       http://www.springframework.org/schema/beans/spring-beans.xsd
       http://www.springframework.org/schema/context
       http://www.springframework.org/schema/context/spring-context.xsd http://www.springframework.org/schema/tx http://www.springframework.org/schema/tx/spring-tx.xsd http://www.springframework.org/schema/aop http://www.springframework.org/schema/aop/spring-aop.xsd">

    <import resource="applicationContext-dao.xml"/>

    <!--创建Spring事务管理-->
    <bean id="transactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
        <property name="dataSource" ref="dataSource"/>
    </bean>

<!--创建通知-->
    <tx:advice id="txAdvice" transaction-manager="transactionManager">
        <!-- 设置传播行为-->
        <tx:attributes>
            <!-- propagation
                    REQUIRED：表示如果有事务就用事务，没有事务就创建事务
                    SUPPORTS：表示如果有事务就用事务，没有事务就不用事务-->
            <tx:method name="save*" propagation="REQUIRED" />
            <tx:method name="insert*" propagation="REQUIRED"/>
            <tx:method name="delete*" propagation="REQUIRED"/>
            <tx:method name="update*" propagation="REQUIRED"/>
            <tx:method name="find*" propagation="SUPPORTS" read-only="true"/>
            <tx:method name="get*" propagation="SUPPORTS" read-only="true"/>
            <tx:method name="query" propagation="SUPPORTS" read-only="true" />
        </tx:attributes>
    </tx:advice>


    <!-- 配置动态代理对象-->
    <aop:config>
        <aop:pointcut id="aop_pointcut" expression="execution(* com.service.*.*(..))"/>
        <aop:advisor advice-ref="txAdvice" pointcut-ref="aop_pointcut"/>
    </aop:config>

</beans>
```



Controller层:

1. Springmvc.xml

   包扫描器， 扫描@Oontroller 注解的类。

   配置注解驱动

   配置视图解析器

   ```
   <?xml version="1.0" encoding="UTF-8"?>
   <beans xmlns="http://www.springframework.org/schema/beans"
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
          xmlns:context="http://www.springframework.org/schema/context"
          xmlns:mvc="http://www.springframework.org/schema/mvc"
          xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd http://www.springframework.org/schema/mvc http://www.springframework.org/schema/mvc/spring-mvc.xsd">
   
       <!-- 配置controller扫描包-->
       <context:component-scan base-package="com.controller" />
   
       <!-- 配置SpringMvc注解驱动
           需要注意导入的约束是xmlns:mvc
       -->
       <mvc:annotation-driven />
   
       <!-- 配置视图解析器
           就是在输入返回页面路径的时候不需要写完整的映射路径
       -->
       <bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
           <property name="prefix" value="/WEB-INF/jsp"/>
           <property name="suffix" value=".jsp"/>
       </bean>
   
   </beans>
   ```



Web.xml文件:

1.配置spring

2、配置前端控制器

```
<!DOCTYPE web-app PUBLIC
 "-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN"
 "http://java.sun.com/dtd/web-app_2_3.dtd" >

<web-app>
  <display-name>Archetype Created Web Application</display-name>

  <!-- 设置一个初始参数，传入Spring配置文件路径
    参数名：contextConfigLocation
    参数内容：classpath:spring/applicationContext*.xml  表示在spring文件夹下所有的applicationContext开头的Xml配置文件
  -->
  <context-param>
    <param-name>contextConfigLocation</param-name>
    <param-value>classpath:spring/applicationContext*.xml</param-value>
  </context-param>
  
  <!-- 通过一个监听器来加载Spring配置文件-->
  <listener>
    <listener-class>org.springframework.web.context.ContextLoaderListener</listener-class>
  </listener>


  <!-- 配置一个Servlet，让所有的请求都通过SpringMvc来接收-->
  <servlet>
    <servlet-name>SrpingMvc</servlet-name>
    <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
    <!-- 注入SpringMvc.xml的配置文件路径-->
    <init-param>
      <param-name>contextConfigLocation</param-name>
      <param-value>classpath:/spring/SpringMvc.xml</param-value>
    </init-param>
  </servlet>
  <servlet-mapping>
    <servlet-name>SrpingMvc</servlet-name>
    <!-- 让所有的.action请求都让Spring来接受-->
    <url-pattern>*.action</url-pattern>
  </servlet-mapping>

</web-app>
```



> 当配置完成后，下面用一个例子开发一个查询的功能

在Service层定义IItemService接口

```
import com.pojo.Item;

import java.util.List;

public interface IItemService {
    public List<Item> queryAll();
}
```

> 定义一个Service接口，其中有一个查询全部的方法

定义ItemServiceImpl实现类

```
package com.service;

import com.mapper.ItemMapper;
import com.pojo.Item;
import com.pojo.ItemExample;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service(value = "ItemService")
public class ItemServiceImpl implements IItemService {

    @Autowired //在applicationContext-dao.xml配置文件配置，Mapper的扫描包
    private ItemMapper itemMapper ; 

    @Override
    public List<Item> queryAll() {
        ItemExample itemExample = new ItemExample();
        itemExample.createCriteria().andNameLike("%%");
        List<Item> items = itemMapper.selectByExample(itemExample);
        return items;
    }
}
```

> 在这个i实现类中，需要定义一个属性，这个属性就是通过逆向工程创建出来接口，通过Spring注入的方式传递进来，这个接口是由Spring自动创建的，在applicationContext-dao.xml配置文件配置，Mapper的扫描包

在controller层定义ItemController类

```
package com.controller;

import com.pojo.Item;
import com.service.IItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class ItemController {

    @Autowired
    private IItemService iItemService ;

    @RequestMapping("/itemList.action")
    public ModelAndView queryItemAll(){
        List<Item> items = this.iItemService.queryAll();
        ModelAndView modelAndView = new ModelAndView();
        System.out.println(items);
        modelAndView.addObject("itemList",items);
        modelAndView.setViewName("itemList");
        return modelAndView ;
    }
}
```

>  在控制定义一个Servlet，也就是调用DAO层查询数据，并设置参数和返回的页面路径

在WEB-INF/JSP文件下创建itemList.jsp

```
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%--
  Created by IntelliJ IDEA.
  User: tonytucker
  Date: 2019/9/26
  Time: 6:08 下午
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="false" %>
<html>
<head>
    <title>商品查询</title>
</head>
<body>
    <form action="itemList.jsp" method="post">
        <table width="100%" border="1" >
            <tr>
                <td>商品名称</td>
                <td>商品价格</td>
                <td>商品描述</td>
                <td>生产日期</td>
            </tr>
            <c:if test="${not empty itemList}" >
                <c:forEach items="${itemList}" var="item">
                    <tr>
                        <td>${item.name}</td>
                        <td>${item.price}</td>
                        <td>${item.detail}</td>
                        <td><fmt:formatDate value="${item.createtime}" pattern="YYYY-MM-dd HH:mm:ss"/></td>
                    </tr>
                </c:forEach>
            </c:if>
        </table>
    </form>
</body>
</html>
```

> 这个JSP主要用户数据的输出显示
>
> 要注意的是如果EL表达式无效，则需要设置isELIgnored=false

之后在启动Tomcat访问http://localhost:8080/工程名/itemList.action，就可以查询数据来



### 5、接收页面的参数

> 当页面发送请求给Mvc的时候，往往都会传递参数，controller层就可以用一下方式接收参数

定义Controller类

```
@RequestMapping("/queryById.action")
public ModelAndView queryById1(HttpServletRequest request){ // 通过接收request对象
    String id = request.getParameter("id");  //接收页面传递过来的参数
    
    Useror useror = this.iUserorService.queryById(Integer.parseInt(id)); // 调用Service层执行业务操作 
    
    ModelAndView modelAndView = new ModelAndView();
    modelAndView.addObject("user",useror); // 保存参数
    modelAndView.setViewName("UserorEdit");
    return modelAndView ;
}
```

> 接收参数就可在控制层中的方法，接收Request对象，SpringMvc会自动判断传递进来，
>
> 然后就可以通过request.getParameter（）的方法接收传递过来的参数

第二种写法

定义Controller类

```
@RequestMapping("/queryById.action")
public String queryById(HttpServletRequest request, Model model){ //接好Model对象
    String id = request.getParameter("id"); // 接收传递回来的参数
    Useror useror = this.iUserorService.queryById(Integer.parseInt(id)); // 执行业务层

    model.addAttribute("user",useror); // 设置参数
    return "UserorEdit" ;  //返回页面路径
}
```

> 和第一种相比相对简单一点，这样就可以不用创建ModelAndView的对象，减少代码

### 6、绑定简单参数

> 绑定简单的参数，如果从页面中传递一个int的ID数据，那么可以在方法中直接写一个参数名称
>
> 参数名称要与传递过来的参数名称保持一致

```
@RequestMapping("/queryById2.action")
public String queryById2(int id,Model model){ // 与传递的参数名称保持一致

    Useror useror = this.iUserorService.queryById(id) ; //调用Service层
    model.addAttribute("user",useror); //设置参数
    return "UserorEdit" ; // 返回页面
}
```

> 接收的参数最好使用包装类，应为包装可以为null，基本数据类型不能为null

第二种写法

```
@RequestMapping("/queryById3.action")
public String queryById3(@RequestParam(value = "id",required = true,defaultValue = "1")Integer id,Model model){
    Useror useror = this.iUserorService.queryById(id);
    model.addAttribute("user",useror);
    return "UserorEdit" ;
}
```

> 第二种写法是为接收参数设置基本的属性
>
> value — 表示接受的参数名称
>
> required = 表示如果没有此参数是否报错 true表示会报错，fasle表示不报错
>
> defaultValue — 表示如果没有此参数，设置默认的参数

注意：如果返回的页面不需要参数的话，可以不接受Model对象



### 6、接收pojo对象参数

> 在一个页面中，如果传入的参数过多，但是有和POJO对象对应的话，那么SpringMVC可以将从页面传递过来的参数自动封装成Pojo对象

定义一个JSP页面

```
<%--
  Created by IntelliJ IDEA.
  User: tonytucker
  Date: 2019/9/27
  Time: 9:34 上午
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="false" %>
<html>
<head>
    <title>用户修改</title>
</head>
<body>
    <form action="${pageContext.request.contextPath}/updateUser.action" method="post">
        <input type="hidden" name="id" value="${user.id}">
        <input type="hidden" name="birthday" value="${user.birthday}">
        <table border="1" width="70%" align="center">
            <tr>
                <td>用户名称:</td>
                <td><input name="username" type="text" value="${user.username}"></td>
            </tr>
            <tr>
                <td>用户性别</td>
                <td><input name="sex" type="text" value="${user.sex}"></td>
            </tr>
            <tr>
                <td>用户住址</td>
                <td><textarea rows="3" cols="30" name="address">${user.address}</textarea></td>
            </tr>
            <tr>
                <td colspan="3"><input type="submit" value="修改"></td>
            </tr>
        </table>
    </form>
</body>
</html>
```

> 在这个页面中有很多参数，而且每个参数的Name都和Useroor的pojo对象的属性对应
>
> 这时候控制层可以直接接收Pojo对象

定义controller

```
@RequestMapping("/updateUser.action")
public String updateUseror(Useror useror){
    this.iUserorService.updateUser(useror);
    return "success" ;
}
```

> 在这个控制层中，可以直接接收一个Useror的POJO对象，SpringMVC会自动封装

### 7、乱码的解决

> 关于乱码，有分两种情况，一种是get请求，一种是post请求
>
> get请求可以通过修改Tomcat的Service配置文件解决
>
> post请求可以通过过滤器解决

解决get请求乱码

修改Tomcat的Server.xml配置文件

```
 <Connector port="8080" protocol="HTTP/1.1"
               connectionTimeout="20000"
               redirectPort="8443" URLEncoding="UTF-8"/>
```

> 在server配置文件中，修改端口的地方，添加一个URLEncoding="UTF-8"，这样就可以解决get请求的乱码

解决Post请求乱码

修改Web.xml文件

```
<!-- 设置过滤器，使用Spring过滤器，将字符集全部设置成UTF-8 -->
<filter>
    <filter-name>encodind</filter-name>
    <filter-class>org.springframework.web.filter.CharacterEncodingFilter</filter-class>
    <init-param>
        <param-name>encoding</param-name>
        <param-value>UTF-8</param-value>
    </init-param>
</filter>
<filter-mapping>
    <filter-name>encodind</filter-name>
    <url-pattern>/*</url-pattern>
</filter-mapping>
```

> 设置一个Spring中的一个字符过滤器，过滤所有的请求，让这些请求的字符都设置成UTF-8

### 8、接收复杂参数使用VO

> 当一个页面需要向JSP很多个参数，但单个Pojo对象又不能全部接受，这个时候就用到复杂参数接受

定义JSP页面

```
<form action="${pageContext.request.contextPath}/queryByIdName2.action" method="post">
        <table width="100%" border="1">
            <tr>
                <td>用户ID</td>
                <td><input name="useror.id" type="text"/></td>
                <td>用户名称:</td>
                <td><input name="useror.username" type="text"></td>
                <td>商品ID</td>
                <td><input name="item.id" type="text"/></td>
                <td>商品ID</td>
                <td><input name="item.name" type="text"/></td>
                <td><input type="submit" value="查询"></td>
            </tr>
        </table>
    </form>
```

> 在这个JSP页面中接受四个参数，分别是userid,username,itemId,ItemName

定义一个VO对象

```
public class UserorVo {

    private Useror useror ;

    private Item item;

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public Useror getUseror() {
        return useror;
    }

    public void setUseror(Useror useror) {
        this.useror = useror;
    }
}
```

> 这个VO对象包括了Useror，和Item对象，Useror接受User的ID和username，Item接收Imte的ID和Item的name

定义Conortller

```
@RequestMapping("/queryByIdName2.action")
public String findByName(UserorVo vo){ // 参数直接传入Vo对象，Spring会自动封装
    
		// 打印接收的参数
    System.out.println(vo.getUseror().getId()); 
    System.out.println(vo.getUseror().getUsername());
    System.out.println();
    System.out.println(vo.getItem().getId());
    System.out.println(vo.getItem().getName());

    return "UserorList" ; //返回页面
}
```

> 在这个控制层的方法中，直接接收定义的VO对象，这个对象包括了其他两个POJO对象，Spring就会自动封装着两个对象到Vo对象中

需要注意的是，JSP页面的name一定要写成，对象.属性名否则会出错



### 9、日期格式转换器

> 在JSP页面中显示日期都是通过fmt:formatDate标签进行格式化输出
>
> 如果需要修改这个参数，向服务器发送一个updateUser.action的请求
>
> 这个请求是进行数据的修改操作，那么Spirng在进行日期格式的传递的时候，是不会自动将字符串的日期转换成Date数据的
>
> 所以需要自定义一个日期格式的转换器来进行转换

定义JSP页面

```
<form action="${pageContext.request.contextPath}/updateUser.action" method="post">
    <input type="hidden" name="id" value="${user.id}">
    <table border="1" width="70%" align="center">
        <tr>
            <td>用户名称:</td>
            <td><input name="username" type="text" value="${user.username}"></td>
        </tr>
        <tr>
            <td>用户性别</td>
            <td><input name="sex" type="text" value="${user.sex}"></td>
        </tr>
        <tr>
            <td>用户日期</td>
            <td><input name="birthday" type="text" value="<fmt:formatDate value="${user.birthday}" pattern="yyyy-MM-dd HH:mm:ss"/>"></td>
        </tr>
        <tr>
            <td>用户住址</td>
            <td><textarea rows="3" cols="30" name="address">${user.address}</textarea></td>
        </tr>
        <tr>
            <td colspan="3"><input type="submit" value="修改"></td>
        </tr>
    </table>
</form>
```

> 这是一个用户信息修改页面，用户修改四个参数，这个页面的数据是从其他请求中传递过来的，修改数据后提交到updateUser.action这个请求来接受
>
> 如果用户修改日期数据，那么传递给updateUser.action的应该是一个字符串，所以需要定义一个转换器，用来转换日期数据，将字符串的日期数据转换成Date的日期数据

定义DateConverter 日期转换器

```
package com.converter;

import org.springframework.core.convert.converter.Converter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/*
* 配置转换器
* 将Spring的数据类型，转换成Date的数据类型
* */
public class DateConverter implements Converter<String,Date> {

    @Override
    public Date convert(String source) { //接收从JSP传递过来的参数
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = simpleDateFormat.parse(source);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date ;
    }
}
```

> 定义转换器需要让类实现一个Converter接口，这个接口有一个范型，左边为传入的参数类型，右边为转换后的参数类型
>
> 这个接口需要复写一个方法convert()，这个方法中的参数就是传递进来的字符型的日期数据
>
> 让后加入自己逻辑转换成Date日期数据返回出去
>
> Spring就会将转换后的日期数据封装

配置applicationContext-mvc.xml文件

```
<!-- 配置注解驱动
    conversion-service 创建好的自定义类型转换器
-->
<mvc:annotation-driven conversion-service="DateConversionService"/>

<!-- 创建一个自定义类型转换器，Bean-->
<bean id="DateConversionService" class="org.springframework.format.support.FormattingConversionServiceFactoryBean">
    <!-- 需要传入一个Set集合
        这个集合就是自定义转换器的类路径
    -->
    <property name="converters">
        <set>
            <bean class="com.converter.DateConverter"/>
        </set>
    </property>
</bean>
```

> 在这个配置文件中，创建一个自定义类型转换器，在注入一个Set集合，集合内容就是自定义转换器的bean
>
> 然后<mvc:annotation-driven conversion-service="DateConversionService"/> 标签中指向创建好的转换器ID

这样当用户修改数据的时候，显示给用户的是格式化的日期数据，封装的时候，Spring会自动将日期数据通过用户定义的转换器，自动转换成Date数据封装在Pojo对象中